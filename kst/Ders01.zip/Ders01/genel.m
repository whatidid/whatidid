syms k n z;
y=2^k;
Y=ztrans(y)
d=iztrans(z^0,k)