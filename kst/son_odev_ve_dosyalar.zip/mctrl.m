% A=Acr
n=5; r=2;
Qc_tam=0;
while rank(Qc_tam)<n,
    A=round(randn(n)*3), B=round(randn(n,r)*2),
    Qc_tam=[B A*B A^2*B A^3*B A^4*B]
end
% A=[-a11          a12*w(i)+wg       a13             a14*w(i);
%     -a12*w(i)-wg     -a11        -a14*w(i)            a13;
%      a31          -a41*w(i)        -a33         wg-bbsigma*w(i);
%      a41*w(i)         a31       -wg+bbsigma*w(i)      -a33       ];
% B=[-b13 0; 0 -b13; b33 0; 0 b33];
Qc=0;
while rank(Qc)<n,
    p0=0
    p1=2, p2=n-p1
    Qc=[B(:,1) A*B(:,1)       B(:,2)  A*B(:,2) A^2*B(:,2)]
end
Bcr=zeros(n,r); Bcr(p1,1)=1; Bcr(p1+p2,2)=1;
Tr=Bcr'*inv(Qc)
T(p0+1,:)=Tr(1,:); T(p0+p1+1,:)=Tr(2,:);
T(p0+2,:)=T(p0+1,:)*A;
T(p0+p1+2,:)=T(p0+p1+1,:)*A;
T(p0+p1+3,:)=T(p0+p1+2,:)*A;
% T(p0+p1+3,:)=T(p0+p1+2,:)*A;
Acr=T*A*inv(T), ax=-Acr([p1 p1+p2],:),
kctr1=poly([-6,-7]); kctr1=kctr1(end:-1:2);
kctr2=poly([-8,-9 -10]); kctr2=kctr2(end:-1:2);
Kcr=[[kctr1;[0 0]] [[0 0 0];kctr2]],
kanonik=eig(Acr-Bcr*(Kcr-ax))
TB=T*B; Sc=inv(TB'*TB)*TB'*Bcr
K=Sc*(Kcr-ax)*T,
orijinal=eig(A-B*K)