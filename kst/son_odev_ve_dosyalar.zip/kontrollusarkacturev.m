function xd=kontrollusarkacturev(t,x)
global g k r m u i
g=9.81; % Yer�ekimi ivmesi
k=0.5; % s�rt�nme katsay�s� (s�rt�nme kuvveti =-k*w modelne g�re)
r=1; % �p boyu
m=1; % K�tle
xd=[x(2);
    -g/r*sin(x(1))-k/m/r*x(2)+u(i)/r^2];
end