% clear all
% Durum geri besleme kazan� matrisini bulur (tek giri�li sistem)
n=3;
lambdac=[-5 -6 -7]; % �stenen �zde�erler (n tane)
% Belirli A ve B i�in y�ld�zl� aral��� comment yap�n
 A=[-5 10 0;0 -3 -8; 3 1 -2]; B=[1 -2 2]'; 
 C=eye(3); D=zeros(3,1); % ��k��ta t�m durum de�i�kenlerini g�rmek i�in
% **********************************
% Qc=0;
% while rank(Qc)<n,
%     A=round(randn(n)*4); B=round(randn(n,1)*4);
    Qc=B; i=1;
    while i<n,
        Qc=[Qc A*Qc(:,i)]; % S�radaki s�tun= A*(bir �nceki s�tun)
        i=i+1;
    end
%     % Denetlenebilir ise rank(Qc)=n
% end
% **********************************
aci=poly(A); % A 'n�n karakteristik polinom katsay�lar� sat�r
alfac=poly(lambdac); % �stenen karakteristik polinom katsay�lar� sat�r
Kcr=alfac-aci; Kcr=Kcr(n+1:-1:2); % S�ras� �evriliyor
% Kanonik formda
aci=aci(n+1:-1:2); % n+1. katsay�dan 2. katsay�ya kadar ters s�rayla sat�r
Acr=[zeros(n-1,1) eye(n-1);
               -aci        ];
Bcr=[zeros(n-1,1);1];
Ac_cr=Acr-Bcr*Kcr;
eig(Ac_cr) % kanonik bi�imde sa�lamas�

% D�n���m matrisi
T(1,:)=Bcr'*inv(Qc); i=1;
while i<n, T(i+1,:)=T(i,:)*A; i=i+1; end
% Orijinal formda
K=Kcr*T;
Ac=A-B*K;
eig(Ac) % sa�lamas�