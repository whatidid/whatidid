global g k r m u i
dt=0.001; t0=0; ts=30; % zaman ad�m�, ba�lang�� ve sonu� anlar�
x0=[pi/6;0]; % ilk a�� 30 drc, ilk h�z 0
g=9.81; % Yer�ekimi ivmesi
k=0.5; % s�rt�nme katsay�s� (s�rt�nme kuvveti =-k*w modelne g�re)
r=1; % �p boyu
m=1; % K�tle
    % t(1)=t0; i=1;
    % x=x0;
% Yukar�daki gibi ilk atamalar her ad�mda diziyi b�y�tmeye �al��t��� i�in
% uzad�k�a daha da yava�lar. Daha iyi bir yol ��yledir:
nt=floor((ts-t0)/dt)+1;
t=zeros(1,nt); %hepsi s�f�r olan sat�r dizi
x=[t;t]; % Ya da zeros(2,nt)
u=t; thetaref=t; thetarefd=t; thetarefdd=t; 
% Boyutlar� a�m�� olduk.
% �imdi ba�lang�� �artlar�:
t(1)=t0; x(:,1)=x0;
% Kontrol parametreleri
lambda1=-20-5j; lambda2=lambda1'; % e�lenik �ift
al=poly([lambda1,lambda2]);
alfa0=al(3); alfa1=al(2);

% ��z�m ba�l�yor
for i=1:nt-1,
% Runga-Kutta metodu
    % Sistem ��z�m�
    k1=kontrollusarkacturev(t(i),x(:,i))*dt;
    k2=kontrollusarkacturev(t(i)+0.5*dt,x(:,i)+0.5*k1)*dt;    
    k3=kontrollusarkacturev(t(i)+0.5*dt,x(:,i)+0.5*k2)*dt;
    k4=kontrollusarkacturev(t(i)+dt,x(:,i)+k3)*dt;
    dx=(k1+2*k2+2*k3+k4)/6;
    x(:,i+1)=x(:,i)+dx;
    % Denetim
    fref=0.5; Aref=10;
    thetaref(i)=Aref*sin(2*pi*fref*t(i)); % �stenen theta(=x1 talebi)
    thetarefd(i)=Aref*2*pi*fref*cos(2*pi*fref*t(i)); % t�revi
    thetarefdd(i)=-Aref*4*pi^2*fref^2*sin(2*pi*fref*t(i)); % 2. t�revi
    u(i+1)=r^2*thetarefdd(i)+m*g*r*sin(0.2*t(i))+alfa1*r*thetarefd(i)-alfa1*r*x(2,i)+alfa0*r*(thetaref(i)-x(1,i));
    t(i+1)=t(i)+dt;
end
i=i+1;
% Sonda kopukluk olmas�n diye
thetaref(i)=Aref*sin(2*pi*fref*t(i)); % �stenen theta=x1
thetarefd(i)=Aref*2*pi*fref*cos(2*pi*fref*t(i)); % t�revi
thetarefdd(i)=-Aref*4*pi^2*fref^2*sin(2*pi*fref*t(i)); % 2. t�revi

figure(1), plot(t,x(1,:),t,thetaref,t,thetaref-x(1,:)); zoom on
set(1,'Name','A��lar','Position',[0,40,400,300])
figure(2), plot(t,x(2,:),'r',t,thetarefd,t,thetarefd-x(2,:));
set(2,'Name','A��sal h�zlar','Position',[400,150,400,200])
figure(4),plot(t,u);