n=5; m=2; % Bu boyutlarda bir sistem i�indir.

% Keyfi A ve C matrisleri olu�turmak
Qotam=0;
while rank(Qotam)<5,
    A=round(randn(n)*3), C=round(randn(m,n)*2),
    Qotam=[C; C*A; C*A^2; C*A^3; C*A^4]
end

% Belirli A ve C matrislerinizi kullanacaksan�z a�a��ya yaz�n�z.
% Aksi halde bu iki sat�r� comment yap�n�z.
% A=[2 -4 -4 -1 2;6 -1 9 0 -4;-7 1 2 4 2;3 11 0 4 5;1 8 2 4 1];
% C=[2 -1 -2 -2 -2;1 1 2 -2 -6];

% �ndirgenmi� g�zlenebilirlik matrisini yazmak
% Bu d�ng�den ��k�lm�yorsa  p1,p2'yi de�i�tirmek ve ek d�zenlemeler
% gerekir.
Qo=0;
while rank(Qo)<5,
    p0=0
    p1=2, p2=n-p1
    Qo=[C(1,:); C(1,:)*A;    C(2,:); C(2,:)*A; C(2,:)*A^2]
end

% Kanonik bi�im Cyildiz matrisi
Cob=zeros(m,n); Cob(1,p1)=1; Cob(2,p1+p2)=1;

% D�n���m matrisi
Rr=inv(Qo)*Cob'  % Ba�lang�� s�tunlar�
R=zeros(n);  % Sadece boyutland�rma
R(:,p0+1)=Rr(:,1); R(:,p0+p1+1)=Rr(:,2);
R(:,p0+2)=A*R(:,p0+1); % Di�er s�tunlar
R(:,p0+p1+2)=A*R(:,p0+p1+1);
R(:,p0+p1+3)=A*R(:,p0+p1+2),

% Kanonik bi�imde kazan�, bloklar i�in istenen �zde�erlere g�re
Aob=inv(R)*A*R, ay=-Aob(:,[p1 p1+p2]),
Lob1=poly([-7,-7])'; Lob1=Lob1(end:-1:2);
Lob2=poly([-6,-6, -6])'; Lob2=Lob2(end:-1:2);
Lob=[Lob1,[0;0];[0;0;0],Lob2],
kanonik=eig(Aob-(Lob-ay)*Cob) % sa�lamas�

% Orijinal bi�ime d�n��
CR=C*R; So=Cob*CR'*inv(CR*CR')
L=R*(Lob-ay)*So,
% Sa�lamas�
orijinal=eig(A-L*C)
