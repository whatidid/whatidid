function varargout = ciftfigur(varargin)
% CIFTFIGUR M-file for ciftfigur.fig
%      CIFTFIGUR, by itself, creates a new CIFTFIGUR or raises the existing
%      singleton*.
%
%      H = CIFTFIGUR returns the handle to a new CIFTFIGUR or the handle to
%      the existing singleton*.
%
%      CIFTFIGUR('CALLBACK',hOb,eventData,hand,...) calls the local
%      function named CALLBACK in CIFTFIGUR.M with the given input arguments.
%
%      CIFTFIGUR('Property','Value',...) creates a new CIFTFIGUR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ciftfigur_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ciftfigur_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ciftfigur

% Last Modified by GUIDE v2.5 26-Mar-2015 11:51:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ciftfigur_OpeningFcn, ...
                   'gui_OutputFcn',  @ciftfigur_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ciftfigur is made visible.
function ciftfigur_OpeningFcn(hOb, eventdata, hand, varargin)
% This function has no output args, see OutputFcn.
% hOb    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% hand    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ciftfigur (see VARARGIN)

hand.t = (0:0.01:10)';
hand.x = cos(2*hand.t);
hand.y = sin(hand.t);

hand.fig=hOb;
hand.ust=findobj('Tag','ust');
hand.alt=findobj('Tag','alt');

% Choose default command line output for ciftfigur
hand.output = hOb;

% Update hand structure
guidata(hOb, hand);

% UIWAIT makes ciftfigur wait for user response (see UIRESUME)
% uiwait(hand.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ciftfigur_OutputFcn(hOb, eventdata, hand) 
% varargout  cell array for returning output args (see VARARGOUT);
% hOb    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% hand    structure with handles and user data (see GUIDATA)

% Get default command line output from hand structure
varargout{1} = hand.output;


% --- Executes on button press in dogru.
function dogru_Callback(hOb, eventdata, hand)
% hOb    handle to dogru (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% hand    structure with handles and user data (see GUIDATA)
set(hand.fig,'CurrentAxes',hand.ust)
hx=plot(hand.t,[hand.t,hand.x]);

% --- Executes on button press in sinus.
function sinus_Callback(hOb, eventdata, hand)
% hOb    handle to sinus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% hand    structure with handles and user data (see GUIDATA)
set(hand.fig,'CurrentAxes',hand.alt)
hy=plot(hand.t,[hand.y]);
for i=1:500;
    P=get(hand.alt,'Position');
    set(hand.alt,'Position',P+[0.1 0 0 0]);
    Q=get(hand.ust,'Position');
    set(hand.ust,'Position',Q-[-0.15 0.03 0.1 0]);
    pause(0.01)
end
