global Ra_La Kb_La b_La Kb_J B_J b_J va TL i
%% Sim�lasyon parametreleri
t0=0; ts=10; dt=0.0001; % ilk ve son zamanlar ile zaman ad�m�
x0=[10;10]; % [ia;w] vekt�r�n�n ba�lang�� �artlar�
% H�z talebini d�ng�  i�inde "istenen h�z" yazan sat�ra giriniz.

%% Motor parametreleri
Ra=0.2678; % Armat�r direnci (ohm)
La=0.02678; % Armat�r end�ktans� (H)
Kb=0.3472; % Z�t emk sabiti (Vs/rad) veya tork sabiti (Nm/A)
B=0.0045; % S�rt�nme sabiti (Nm.s/rad)
J=0.009; % Eylemsizlik momenti (kg.m^2)
vmax=80; vmin=-vmax;

%% Hesaplanm�� parametreler
Ra_La=Ra/La; Kb_La=Kb/La; b_La=1/La;
Kb_J=Kb/J; B_J=B/J; b_J=1/J;
% G�zleyici 3. mertebel
A3=[-Ra_La -Kb_La 0;
    Kb_J  -B_J -b_J;
    0     0     0];
B3=[b_La; 0; 0];
A2=A3(1:2,1:2); B2=B3(1:2);
C=[1 0 0];

%% G�zleyici kazan� matrisi
lambdao=[-25 -25 -25]; n=3;
Qo=[C;C*A3;C*A3*A3];
aoi=poly(A3); % A3 '�n karakteristik polinom katsay�lar� sat�r
alfao=poly(lambdao); % �stenen karakteristik polinom katsay�lar� sat�r
Lob=(alfao-aoi)'; Lob=Lob(n+1:-1:2); % S�ras� �evriliyor
% Kanonik formda
aoi=aoi(n+1:-1:2); % n+1. katsay�dan 2. katsay�ya kadar ters s�rayla sat�r
Aob=[ [zeros(1,n-1) ; eye(n-1)] ,    -aoi' ]; % Kanonik bi�imin Ayildiz matrisi
Cob=[zeros(1,n-1)  1];
Ao_ob=Aob-Lob*Cob; 
% eig(Ao_ob) % kanonik bi�imde sa�lamas�
% D�n���m matrisi
R(:,1)=inv(Qo)*Cob'; i=1;
while i<3, R(:,i+1)=A3*R(:,i); i=i+1; end
% Orijinal formda
L=R*Lob;
Ao=A3-L*C;
% eig(Ao) % sa�lamas�

%% Kontrol kazan� matrisi
lambdac=[-30 -35]; n=2; % �stenen �zde�erler (n tane)
A2=A3(1:2,1:2);
Qc=[B2  A2*B2];
aci=poly(A2); % A2 'n�n karakteristik polinom katsay�lar� sat�r
alfac=poly(lambdac); % �stenen karakteristik polinom katsay�lar� sat�r
Kcr=alfac-aci; Kcr=Kcr(n+1:-1:2); % S�ras� �evriliyor
% Kanonik formda
aci=aci(n+1:-1:2); % n+1. katsay�dan 2. katsay�ya kadar ters s�rayla sat�r
Acr=[zeros(n-1,1) eye(n-1);
               -aci        ];
Bcr=[zeros(n-1,1);1];
Ac_cr=Acr-Bcr*Kcr;
% eig(Ac_cr) % kanonik bi�imde sa�lamas�
% D�n���m matrisi
T(1,:)=Bcr'*inv(Qc); i=1;
while i<n, T(i+1,:)=T(i,:)*A2; i=i+1; end
% Orijinal formda
K=Kcr*T;
Ac=A2-B2*K;
% eig(Ac) % sa�lamas�

%% Ba�lang�� de�erleri ve boyutland�rmalar�
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,nt); % �imdilik s�f�r olsun (sat�r)
va=t; TL=t; % �imdilik s�f�r olsunlar (sat�r)
x=[t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [ia;w] vekt�r�)
xob=[t;t;t]; % G�zleyici durum de�i�kenleri 
iaref=t; wref=t; TLref=t; r=t; y=t;
t(1)=t0;
x(:,1)=x0;


%% D�ng� ba�l�yor
for i=1:nt-1
    t(i+1)=t(i)+dt;
%     va(i)=60; % �imdilik sabit (denetim iptal testi i�in)
    % Y�kleme
    if t(i)>=4, TL(i)=3.2; end 
    x(:,i+1)=x(:,i)+dcmotor_turevi(t(i),x(:,i))*dt; % Euler metodu
    y(i+1)=x(1,i+1)+0.2*randn(1); % Ak�m �l��m� (ger�ek�i olsun diye bozucu etki uygulanm��)
    % Referans modeli dinamik tan�mlamak yerine istenen h�za (wref) g�re
    % gereken ak�m (iaref) ve bunlar i�in gereken giri� voltaj� (r) diye
    % hesaplayarak kullan�yoruz. Ayn� hesaba geliyor.
    wref(i)=195; % istenen h�z
    iaref(i)=(B/Kb)*wref(i)+xob(3,i)/Kb;
    r(i)=Ra*iaref(i)+B*La/Kb*(Kb_J*iaref(i)-B_J*wref(i)-b_J*xob(3,i))+Kb*wref(i);
    % G�zleyici
    xob(:,i+1)=xob(:,i)+(A3*xob(:,i)+[B2;0]*va(i)+L*(y(i)-xob(1,i)))*dt; % Euler metodu
    % Durum geribeslemeli denetim
    va(i+1)=r(i)+K*([iaref(i);wref(i)]-xob(1:2,i));
    % S�n�rlama (ger�ekte kayna��m�z s�n�rl� oldu�u i�in)
    if va(i+1)>vmax, va(i+1)=vmax; end
    if va(i+1)<vmin, va(i+1)=vmin; end
end
%% �izimler
figure(1),plot(t,x(1,:),t,xob(1,:)),set(1,'Name','Ak�m ve tahmini')
figure(2),plot(t,x(2,:),t,xob(2,:)),set(2,'Name','H�z ve tahmini')
figure(3),plot(t,TL,t,xob(3,:)),set(3,'Name','Y�k torku ve tahmini')
figure(4),plot(t,va,t,r),set(4,'Name','Giri� voltaj� va ve referans model giri�i r')