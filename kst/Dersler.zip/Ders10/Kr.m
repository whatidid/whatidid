Kr=inv(-C*inv(A-B*K)*B+D+D*K*inv(A-B*K)*B);
