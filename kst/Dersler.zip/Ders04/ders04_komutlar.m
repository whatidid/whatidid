%-- 05.03.2014 16:04 --%
roots([2 1 12 8 2])
rlocus([2 5 1],[1 2 3])
help rlocus
help zpk
T=zpk([],[0 -1 -2   ],1)
rlocus(T)
alfa=0.253;wd=0.809;
wn=sqrt(alfa^2+wd^2)
ksi=alfa/wn
T
GH=T
clear all
G=zpk([],[0 -1 -2   ],1)
rlocus(G)
help closed
help close
T=coseloop(G)
T=closeloop(G)
G
H=1
T=feedback(G,H)
T=feedback(G*1.8,H)
y=step(T),figure(2),plot(t,y)
y=step(T),figure(2),plot(y)
grid
T=feedback(G*2,H)
y=step(T),figure(2),plot(y)
atand(0.1)
atand(10)

