%-- 12.03.2014 16:13 --%
help bode
help zpk
help frd
payda=poly([0 -10 -10])
payda=poly([0 -10 -10])/100
roots(payda)
pay=poly([-2 -20])
pay=poly([-2 -20])/4
roots(pay)
GH=sys(pay,payda)
GH=tf(pay,payda)
GH=tf(pay,payda) %a��k d�ng� kazanc�
bode(GH)
payda=poly([0 0 -10 -10])/100
GH=tf(pay,payda) %a��k d�ng� kazanc�
bode(GH)
grid
kdB=10^(30/20) % kazanc� 30dB art�rmak i�in �arp�lacak katsay�
GHyeni=kdB*GH
bode(GHyeni)
grid
rlocus(GHyeni/7.906)
rlocus(GHyeni) % k�k yer e�risi yakla��k birim kazan�ta (GH'a 30db eklenmi�i oluyor) karars�zl��a ge�iyor
wn=100;ksi=0.5;T=tf(wn^2,[1 2*ksi*wn wn^2]) % temel 2. mertebe s�n�ml� sal�n�ml� sistem)
bode(T)
wn=100;ksi=0.05;T=tf(wn^2,[1 2*ksi*wn wn^2]) % temel 2. mertebe s�n�ml� sal�n�ml� sistem)
bode(T)
F=tf([1 0 0 0 0],
payda=poly([-1e-3 -1e-3 -1e-3 -1e-3 -5e-4 -5e-4 -5e-4])
F=tf([1 0 0 0 0],payda)
bode(F*100)
payda=poly([-1e3 -1e3 -1e3 -1e3 -2000 -2000 -2000])
bode(F*100)
F=tf([1 0 0 0 0],payda)
bode(F*100)
grid
bode(F*1e4)
bode(F*1e9)
bode(F*1e12)