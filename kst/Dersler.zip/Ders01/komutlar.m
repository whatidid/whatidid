%-- 12.02.2014 09:52 --%
2*6
a=3;b=[2 3 4;1 -2 0
1 1 1]
inv(b)
det(b)
a*b
eye(3)
zeros(3)
zeros(3,2)
ones(3,2)
b^2
a=round(randn(5,4)*10)
a=round(rand(5,4)*10-5)
a(2,:)
a(2:4,:)
a
a(:,2:4)
a
b
a=round(rand(3)*10-5)
a*b
a.*b
a.*b % kar��l�kl� elemanlar� �arpar
a^2
a.^2 %te tek elemanlar� karesi
t=sym('t')
y=2*t^2-8
diff(y)
t=1;eval(y) % y(1) de�erii verir
p=t^3
t=sym('t')
p=t^3
Y=laplace(y)
x=sym('x'); f=cos(x); F=laplace(f)
s=j*2,eval(F(s))
F
s=sym('s')
s=j*2,eval(F(s))
F
s=2,eval(F(s))
G=F
s=2,eval(F))
s=2,eval(F)
s=j*2,eval(F)
help laplace
ilaplace(s/(s^2+25))
s
s=sym('s')
ilaplace(s/(s^2+25))
clear t
clear all
help clear
genel
5
genel
help ztrans
help iztrans
x
x.time
x.signals
x.signals(1)
x.signals(1).values
x.signals(1).values(:,1) % 1.s�tun
x
x.signals(1).values
x.signals(2).values
x.time
t=x.time; x1=x.signals(1).values;
plot(t,x1)
grid
plot(t,x1)
grid
figure(1),plot(t,x1)
figure(1),plot(t,x1),grid,zoom on
x2=x.signals(2).values;
figure(2),plot(t,x2)
axis([0 5 -2 8])