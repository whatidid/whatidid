%-- 02.04.2014 15:56 --%
K=0.1;Ki=10;Kd=0;
Kp=0.1;Ki=10;Kd=0;
Kp=0.1;Ki=100;Kd=0;
Kp=0.1;Ki=20;Kd=0;
Kp=1;Ki=20;Kd=0;
Kp=5;Ki=20;Kd=0;
Kp=5;Ki=50;Kd=0;
Kp=5;Ki=20;Kd=0;
Kp=5;Ki=20;Kd=0.1;
Kp=5;Ki=20;Kd=0;
help simulink
sim('pidmodel')
Kp=5;Ki=50;Kd=0;sim('pidmodel')
Kp=5;Ki=20;Kd=0;sim('pidmodel')
Kp=5;Ki=20;Kd=0.1;sim('pidmodel')
Kp=5;Ki=20;Kd=0;sim('pidmodel')
Kp=5;Ki=20;Kd=1;sim('pidmodel')
Kp=5;Ki=20;Kd=0;sim('pidmodel')
Kp=5;Ki=20;Kd=1;sim('pidmodel')
Kp=5;Ki=20;Kd=0;sim('pidmodel')
Kp=5;Ki=20;Kd=10;sim('pidmodel')
Kp=5;Ki=20;Kd=5;sim('pidmodel')
Kp=5;Ki=20;Kd=3;sim('pidmodel')
Kp=5;Ki=20;Kd=13;sim('pidmodel')
Kp=5;Ki=20;Kd=1;sim('pidmodel')
pidkomut
clear all
pidkomut
Ki_dt/dt
Kp
pidkomut
xturev
pidkomut
Ki=0;Kd=0;
Kp=10;
Kp=10;sim('pidmodel')
Kp=100;sim('pidmodel')
Kp=1000;sim('pidmodel')
Kp=10000;sim('pidmodel')
Kp=100000;sim('pidmodel')
Kp=1e6;sim('pidmodel')
Kp=1e8;sim('pidmodel')
Kp=1e18;sim('pidmodel')
Kp=1e6;sim('pidmodel')
Kp=1e3;sim('pidmodel')
Kp=100;sim('pidmodel')
Kp=500;sim('pidmodel')
Kp=300;sim('pidmodel')
Kp=200;sim('pidmodel')
Kp=250;sim('pidmodel')
Kp=220;sim('pidmodel')
Kp=215;sim('pidmodel')
35.34-34.13
Ku=215; Tu=1.21;
Kp=Ku/2; Ki=0; Kd=0 ;sim('pidmodel')
Kp=Ku/2.2; Ki=1.2*Kp/Tu; Kd=0 ;sim('pidmodel')
Kp=Ku*0.6; Ki=2*Kp/Tu; Kd=Kp*Tu/8 ;sim('pidmodel')
Kp=Ku/2.2; Ki=1.2*Kp/Tu; Kd=0 ;sim('pidmodel')
Ki
Kp
Ki=150;
Kp=100; Ki=150; Kd=0 ;sim('pidmodel')
Kp=100; Ki=80; Kd=0 ;sim('pidmodel')
Kp=100; Ki=50; Kd=0 ;sim('pidmodel')
Kp=100; Ki=10; Kd=0 ;sim('pidmodel')
Kp=100; Ki=30; Kd=0 ;sim('pidmodel')
Kp=Ku/2.2; Ki=1.2*Kp/Tu; Kd=0 ;sim('pidmodel')
T=1.4; L=0.25; % ZN basamak tepksi
Kp=T/L; Ki=0; Kd=0; sim('pidmodel')
Kp=0.9*T/L; Ki=0.27*T/L^2; Kd=0; sim('pidmodel')
Kp=1.2*T/L; Ki=0.6*T/L^2; Kd=0.6*T; sim('pidmodel')
Kp=0.9*T/L; Ki=0.27*T/L^2; Kd=0; sim('pidmodel')
Kp
Ki
Kp=5; Ki=10; Kd=0; sim('pidmodel')
Kp=5; Ki=20; Kd=0; sim('pidmodel')