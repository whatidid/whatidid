t0=0; ts=30; dt=1e-3; x0=[1 2];
Ku=8000; Tu=0.07;
Kp=Ku*0.6;
Ki_dt=2*Kp/Tu*dt;
Kd_dt=Kp*Tu/8/dt;
nt=floor((ts-t0)/dt)+1;
t=zeros(1,nt); u=t; r=t; x=[t;t];
eskihata=0; integ=0;
t(1)=t0;
for i=2:nt;
    k1=xturev(t(i-1),x(:,i-1),u(i-1))*dt;
    k2=xturev(t(i-1)+0.5*dt,x(:,i-1)+0.5*k1,u(i-1))*dt;    
    k3=xturev(t(i-1)+0.5*dt,x(:,i-1)+0.5*k2,u(i-1))*dt;
    k4=xturev(t(i-1)+dt,x(:,i-1)+k3,u(i-1))*dt;
    dx=(k1+2*k2+2*k3+k4)/6;
    x(:,i)=x(:,i-1)+dx;
    t(i)=t(i-1)+dt;
    y(i)=x(1,i);
    %PID
    r(i)=5+sign(sin(t(i)/10));
    hata=r(i)-y(i);
    oransal=Kp*hata;
    turevsel=Kd_dt*(hata-eskihata);
    integ=integ+Ki_dt*hata;
    u(i)=oransal+turevsel+integ;
    eskihata=hata;
end
figure(1),plot(t,[y])