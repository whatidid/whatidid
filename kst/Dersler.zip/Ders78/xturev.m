function xd=xturev(t,x,u);
xd=[0 1;
    -3 -4]*x+[0;1]*u +[0;x(1)*cos(x(1))/(1+x(2)^2)];
    