t0=0; ts=80; % Ba�lang�� ve biti� zamanlar�
x0=[2;3];
dt=0.01;
dosya='avci_av_u';

% Boyutland�rma
nt=floor((ts-t0)/dt)+1;
t=0:dt:ts; t=t'; size(t)
x=zeros(2,nt); u=t;

% Referans
x2m=zeros(nt,1)+2+2*sin(2*pi*t/15); % Bu sat�r� de�i�tirebilirsiniz ama alttaki t�revlerini de�i�tirmeyin
x2md=[0;diff(x2m)/dt]; % 1. t�revi
x2mdd=[0;diff(x2md)/dt]; % 2. t�revi
lmd=-1; alfa0=lmd^2; alfa1=-2*lmd;

% Ba�lang�� de�erleri
t(1)=t0; x(:,1)=x0; u(1)=0;

for i=1:nt-1,
    k1=feval(dosya,x(:,i),u(i),t(i))*dt;
    k2=feval(dosya,x(:,i)+k1/2,u(i),t(i)+dt/2)*dt;
    k3=feval(dosya,x(:,i)+k2/2,u(i),t(i)+dt/2)*dt;
    k4=feval(dosya,x(:,i)+k3,u(i),t(i)+dt)*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
    t(i+1)=t(i)+dt;
    %Denetim
    u(i+1)=(-x2mdd(i)-alfa1*x2md(i)-alfa0*x2m(i)-x(1,i)*x(2,i)*(1-x(1,i)+x(2,i)+alfa1)+x(2,i)*(1+alfa0+alfa1) ) / x(2,i);
end

figure(1),plot(t,u),
figure(3), h1=plot(t,x);
legend('Tilki','Tav�an')
set(3,'Position',[15 98 560 420],'Name','Zamana g�re')
set(h1(1),'LineWidth',2)
figure(4), h2=plot(x(1,:),x(2,:));
set(4,'Position',[292 109 432 235],'Name','Tilki&Tav�an')
text(1,2,'�evrim')
%text(2,2.5,'3\alpha_1^2')