function xd=avci_av(x,t);
xd=[-x(1)+x(1)*x(2);
    x(2)-x(1)*x(2)];
end