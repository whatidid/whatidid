function xd=avci_av_u(x,u,t);
xd=[-x(1)+x(1)*x(2)+u;
    x(2)-x(1)*x(2)];
end