t0=0; ts=10; % Ba�lang�� ve biti� zamanlar�
x0=[2;3];
dt=0.01;
dosya='avci_av';

% Boyutland�rma
nt=floor((ts-t0)/dt)+1;
t=zeros(nt,1); x=zeros(2,nt);

% Ba�lang�� de�erleri
t(1)=t0; x(:,1)=x0;

for i=1:nt-1,
    k1=feval(dosya,x(:,i),t(i))*dt;
    k2=feval(dosya,x(:,i)+k1/2,t(i)+dt/2)*dt;
    k3=feval(dosya,x(:,i)+k2/2,t(i)+dt/2)*dt;
    k4=feval(dosya,x(:,i)+k3,t(i)+dt)*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
    t(i+1)=t(i)+dt;
end
figure(3), h1=plot(t,x);
legend('Tilki','Tav�an')
set(3,'Position',[15 98 560 420],'Name','Zamana g�re')
set(h1(1),'LineWidth',2)
figure(4), h2=plot(x(1,:),x(2,:));
set(4,'Position',[292 109 432 235],'Name','Tilki&Tav�an')
text(1,2,'�evrim')
text(2,2.5,'3\alpha_1^2')