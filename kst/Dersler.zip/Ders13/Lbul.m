% clear all
% G�zleyici kazan� matrisini bulur (tek ��k��l� sistem)
n=3;
lambda=[-4 -5 -6]; % �stenen �zde�erler (n tane)
% Belirli A ve C i�in y�ld�zl� aral��� comment yap�n 
 A=[-5 10 0;0 -3 -8; 3 1 -2]; C=[1 -2 2]; %B=[1;2;-1];
% **********************************
% Qo=0;
% while rank(Qo)<n,
%     A=round(randn(n)*4); C=round(randn(1,n)*4);
    Qo=C; i=1;
    while i<n,
        Qo=[Qo; Qo(i,:)*A]; % S�radaki sat�r= (bir �nceki sat�r)*A
        i=i+1;
    end
    % G�zlenebilir ise rank(Qo)=n
% end
% **********************************
ai=poly(A); % A 'n�n karakteristik polinom katsay�lar� sat�r
alfa=poly(lambda); % �stenen karakteristik polinom katsay�lar� sat�r
Lob=(alfa-ai)'; Lob=Lob(n+1:-1:2); % S�ras� �evriliyor
% Kanonik formda
ai=ai(n+1:-1:2), % n+1. katsay�dan 2. katsay�ya kadar ters s�rayla sat�r
Aob=[ [zeros(1,n-1) ; eye(n-1)] ,    -ai' ]; % Kanonik bi�imin A matrisi
Cob=[zeros(1,n-1)  1];
Aoob=Aob-Lob*Cob;
% D�n���m matrisi
R(:,1)=inv(Qo)*Cob'; i=1;
while i<n, R(:,i+1)=A*R(:,i); i=i+1; end
% Orijinal formda
L=R*Lob;
Ao=A-L*C; eig(Ao)