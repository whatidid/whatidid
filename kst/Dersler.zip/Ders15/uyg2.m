function xd=uyg2(x,u);
% x yerine xm, u yerine r verilirse refererans model olarak da
% kullan�labilir
xd=[-x(2);
    x(1) + x(1)*x(2) + u];