function xd=hemrefhemgercek(x,u);
% x yerine xm, u yerine r verilirse refererans model olarak da
% kullan�labilir
xd=[2*x(1)+3*x(2)+x(1)*x(2)+u;
    -x(1)+2*x(2)+x(1)^3+u];