t0=0; tson=20;
x0=[0;0]; xm0=[0;0];
dt=1e-3; t=t0:dt:tson; t=t'; nt=length(t);
x=[t';t']*0; xm=x; u=t*0; r=t*0; % Boyutland�rma
x(:,1)=x0; xm(:,1)=xm0;
for i=1:nt-1;
    % Referans
    xm1(i+1)=cos(t(i+1));
    xm1d=-sin(t(i+1)); xm1dd=-xm1(i+1);
    
    % Kontrol
    payda=xm1d+x(2,i);
    if payda >= 0 && payda < 6e-4, payda=6e-4, end
    if payda < 0 && payda > -6e-4, payda=-6e-4, end
    u(i+1)=-xm1(i+1)-2*payda-xm1dd - x(1,i)*x(2,i)-2*(xm1(i+1)-x(1,i))^2/payda;
    
    % Ger�ek sistem
    k1=uyg2(x(:,i),u(i))*dt;
    k2=uyg2(x(:,i)+k1/2,u(i))*dt; % t olmad��� i�in yazmad�k, r sabit al�nd�.
    k3=uyg2(x(:,i)+k2/2,u(i))*dt;
    k4=uyg2(x(:,i)+k3,u(i))*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
end
V=(xm1-x(1,:)).^2+(-sin(t')+x(2,:)).^2; V=V*0.5;
figure(1),plot(t,[xm1; x(1,:)])
figure(2),plot(t,[-sin(t'); -x(2,:)])
figure(3),plot(diff(V))
