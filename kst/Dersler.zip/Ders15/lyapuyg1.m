t0=0; tson=5;
x0=[1;1]; xm0=[0;0];
dt=1e-3; t=t0:dt:tson; t=t'; nt=length(t);
x=[t';t']*0; xm=x; u=t*0; r=t*0; % Boyutland�rma
x(:,1)=x0; xm(:,1)=xm0;
for i=1:nt-1;
    % Referans model
    r(i+1)=0.05-0.01*sin(t(i+1));
    k1=hemrefhemgercek(xm(:,i),r(i))*dt;
    k2=hemrefhemgercek(xm(:,i)+k1/2,r(i))*dt; % t olmad��� i�in yazmad�k, r sabit al�nd�.
    k3=hemrefhemgercek(xm(:,i)+k2/2,r(i))*dt;
    k4=hemrefhemgercek(xm(:,i)+k3,r(i))*dt;
    xm(:,i+1)=xm(:,i)+(k1+2*k2+2*k3+k4)/6;
    
    % Kontrol
    e1=xm(1,i)-x(1,i); e2=xm(2,i)-x(2,i);
    ufpay=(13*e1-3*e2)*(xm(1,i)*xm(2,i)-x(1,i)*x(2,i))-(3*e1-165*e2)*(xm(1,i)^3-x(1,i)^3);
    ufpayda=10*e1+162*e2;
    if ufpayda >= 0 && ufpayda < 1e-10, ufpayda=1e-10; end
    if ufpayda < 0 && ufpayda > -1e-10, ufpayda=-1e-10; end
    uf=ufpay/ufpayda;
    u(i+1)=r(i+1)+6.5*e1+2.5*e2+uf;
    
    % Ger�ek sistem
    k1=hemrefhemgercek(x(:,i),u(i))*dt;
    k2=hemrefhemgercek(x(:,i)+k1/2,u(i))*dt; % t olmad��� i�in yazmad�k, r sabit al�nd�.
    k3=hemrefhemgercek(x(:,i)+k2/2,u(i))*dt;
    k4=hemrefhemgercek(x(:,i)+k3,u(i))*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
end
figure(1),plot(t,[xm(1,:); x(1,:)])
figure(2),plot(t,[xm(2,:); x(2,:)])
figure(3),plot(t,xm-x)
