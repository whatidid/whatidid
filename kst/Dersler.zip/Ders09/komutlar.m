%-- 09.04.2014 10:08 --%
dcmotor
5.044-4.983
dcmotor
Kp
Ki
Kd
dcmotor
va
dcmotor
va
dcmotor
rand(3)
randn(3)
dcmotor
Kp
Ki
dcmotor
ciftfigur
gui
clear all, close all
figure(1)
h=uicontrol('Name','yaz','Style','button')
uicontrol('Style', 'pushbutton', 'String', 'Clear',...
'Position', [20 20 50 20],...
'Callback', 'cla');        % Pushbutton string callback
% that calls a MATLAB functi
clear all, close all
figure(1)
h=uicontrol('Style', 'pushbutton', 'String', '�iz')
set(h,'Callback','cizsin.m')
set(h,'Callback','cizsin')
guilicizim
clear all, close all
guilicizim
get(hs)
get(hs,'Position')
guilicizim
get(hs)
guilicizim
get(hs)
guilicizim
get(hs)
guilicizim
get(hs)
guilicizim
ht
get(ht)
get(h)
get(ht)
get(ht,'Position')
get(1)
get(1,'Position')
set(ht,'Value','kazan�')
set(ht,'Value',390)
guilicizim