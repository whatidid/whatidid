global Ra_La Kb_La b_La Kb_J B_J b_J va TL i
% Sim�lasyon parametreleri
t0=0; ts=10; dt=0.001; % ilk ve son zamanlar ile zaman ad�m�
x0=[0;0]; % [ia;wr] vekt�r�n�n ba�lang�� �artlar�

% Motor parametreleri
Ra=0.2678; % Armat�r direnci (ohm)
La=0.02678; % Armat�r end�ktans� (H)
Kb=0.3472; % Z�t emk sabiti (Vs/rad) veya tork sabiti (Nm/A)
B=0.0045; % S�rt�nme sabiti (Nm.s/rad)
J=0.009; % Eylemsizlik momenti (kg.m^2)
vmax=200; vmin=-vmax;

% Kontrol parametreleri
Ku=7; Tu=0.06;
% Kp=7; Ki=0; Kd=0;
% Kp=0.5*Ku; Ki=0; Kd=0; % sadece P
Kp=0.45*Ku; Ki=1.2*Kp/Tu; Kd=0; % PI
% Kp=0.6*Ku; Ki=2*Kp/Tu; Kd=Kp*Tu/8; % PID
Kp=0.1; Ki=1.5;

% Hesaplanm�� marametreler
Ra_La=Ra/La; Kb_La=Kb/La; b_La=1/La;
Kb_J=Kb/J; B_J=B/J; b_J=1/J;
Ki_dt=Ki*dt; Kd_dt=Kd/dt;

% Ba�lang�� de�erleri
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,nt); % �imdilik s�f�r olsun (sat�r)
integral=0; eski=0;
va=t; TL=t; % �imdilik s�f�r olsunlar (sat�r)
x=[t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [ia;wr] vekt�r�)
t(1)=t0;
x(:,1)=x0;

% D�ng� ba�l�yor
for i=1:nt-1
    t(i+1)=t(i)+dt;
%     va(i)=60; % �imdilik sabit (denetim yok)
    if t(i)>=4, TL(i)=3; end
    x(:,i+1)=x(:,i)+dcmotor_turevi(t(i),x(:,i))*dt; % Euler metodu
    y=x(2,i+1)+2*randn(1); % H�z �l��m�
    wref=150; % istenen h�z
    
    % PID kontrol
    e=wref-y;
    oransal=Kp*e;
    integral=integral+Ki_dt*e;
    turevsel=(e-eski)*Kd_dt; % e'=(e-eski)/dt
    va(i+1)=oransal+integral+turevsel;
    % Limitleme
    if va(i+1)>vmax, va(i+1)=vmax; end
    if va(i+1)<vmin, va(i+1)=vmin; end
    eski=e;
end
figure(1),plot(t,x)
set(1,'Name','Ak�m ve a��sal h�z')