function [ xd ] = dcmotor_turevi( t,x )
%DCMOTOR_TUREV� Summary of this function goes here
%   Detailed explanation goes here
% Ra_La=Ra/La; Kb_La=Kb/La; b_La=1/La;
% Kb_J=Kb/J; B_J=B/J; b_J=1/J;

global Ra_La Kb_La b_La Kb_J B_J b_J va TL i
xd=[-Ra_La*x(1)-Kb_La*x(2)+b_La*(va(i)+1*randn(1));
    Kb_J*x(1)-B_J*x(2)-b_J*TL(i)];
end

