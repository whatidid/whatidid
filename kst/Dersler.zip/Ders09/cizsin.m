t=0:0.01:10;
plot(t,sin(t)),axis([0 10 -10 10])