
clear all, close all,
figure(1),
h=uicontrol('Style','pushbutton','String','�iz')
set(h,'Callback','cizsin')
hs=uicontrol('Style','slider','Position',[0,50,20,300]);
set(hs,'Callback','genlik','Max',10)
ht=uicontrol('Style','text','Position',[30 350 50 20],'String','kazan�');
