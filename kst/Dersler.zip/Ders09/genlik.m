K=get(hs,'Value');
plot(t,K*sin(t)),axis([0 10 -10 10])
set(ht,'String',K)