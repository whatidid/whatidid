%-- 26.02.2014 16:00 --%
sin(pi/6)
eval('2*3')
eval('a=2*b')
a=2*b
i=5;['x' '0'+i]
i=5;eval(['x' '0'+i '=2*3'])
feval('sin',pi/6)
help cart2pol
[theta,r]=cart2pol(3,4)
theta*180/pi
[theta,r]=feval('cart2pol',3,4)
[t,x] = runga('sarkacturev',0,5,[pi/2;0]);
figure(1),plot(t,x)
[t,x] = runga('sarkacturev',0,5,[pi/2;0]);
figure(1),plot(t,x)
[t,x] = runga('sarkacturev',0,25,[pi/2;0]);
figure(1),plot(t,x)
help ode45
[t,x] = ode45('sarkacturev',0,25,[pi/2;0]);
[t,x] = ode45('sarkacturev',[0:dt:25],[pi/2;0]);
dt=1e-3
[t,x] = ode45('sarkacturev',[0:dt:25],[pi/2;0]);
figure(1),plot(t,x)
[t,x] = ode45('sarkacturev',[0:dt:25],[pi/2;0],1e-9);
[t,x] = ode45('sarkacturev',[0:dt:25],[pi/2;0],1e-15);
[t,x] = ode45('sarkacturev',[0:5],[pi/2;0]);
figure(1),plot(t,x)
[t,x] = ode45('sarkacturev',[0 3 5],[pi/2;0]);
figure(1),plot(t,x)
clear all, close all
clc
sarkac
get(1)
get(1,'Position')
sarkac
get(h1(1))
sarkac
get(1)
gca
h=gca
get(h)
sarkac
help legend
sarkac
t=0:0.1:10;y=sin(t);
help find
find(0)
find(y=0)
find(y==0)
y(1)
find(abs(y)<1e-3)
find(abs(y)<1e-2)
find(abs(y)<1e-1)
find(abs(y)<3e-2)
y(ans)
grid
sarkac
get(h)
[0:pi:10]
sarkac