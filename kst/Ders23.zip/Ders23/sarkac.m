% Bu program bir sarka� modelini Euler metoduyla ��zer ve �izer
clear all, close all
dt=0.001; t0=0; ts=10; % zaman ad�m�, ba�lang�� ve sonu� anlar�
x0=[pi/6;0]; % ilk a�� 30 drc, ilk h�z 0
g=9.81; % Yer�ekimi ivmesi
k=0.5; % s�rt�nme katsay�s� (s�rt�nme kuvveti =-k*w modelne g�re)
r=1; % �p boyu
m=1; % K�tle
    % t(1)=t0; i=1;
    % x=x0;
% Yukar�daki gibi ilk atamalar her ad�mda diziyi b�y�tmeye �al��t��� i�in
% uzad�k�a daha da yava�lar. Daha iyi bir yol ��yledir:
nt=floor((ts-t0)/dt)+1;
t=zeros(1,nt); %hepsi s�f�r olan sat�r dizi
xE=[t;t]; % Ya da zeros(2,nt) (Euler �in)
xR=xE; % Runga-Kutta i�in
% Boyutlar� a�m�� olduk.
% �imdi ba�lang�� �artlar�:
t(1)=t0; xE(:,1)=x0; xR(:,1)=x0;

% ��z�m ba�l�yor
% while t(i)<ts,
%     xE(:,i+1)=xE(:,i)+[xE(2,i);
%                      -g/l*sin(xE(1,i))-k/m/l*xE(2,i)]*dt;
%     t(i+1)=t(i)+dt; i=i+1;
% end

for i=1:nt-1,
% Euler metodu
    xE(:,i+1)=xE(:,i)+sarkacturev(t(i),xE(:,i))*dt;
% Runga-Kutta metodu
    k1=sarkacturev(t(i),xR(:,i))*dt;
    k2=sarkacturev(t(i)+0.5*dt,xR(:,i)+0.5*k1)*dt;    
    k3=sarkacturev(t(i)+0.5*dt,xR(:,i)+0.5*k2)*dt;
    k4=sarkacturev(t(i)+dt,xR(:,i)+k3)*dt;
    dx=(k1+2*k2+2*k3+k4)/6;
    xR(:,i+1)=xR(:,i)+dx;
    
    t(i+1)=t(i)+dt; i=i+1;
end

figure(1), h1=plot(t,xE(1,:),t,xR(1,:)), zoom on
set(1,'Name','A��lar','Position',[0,40,400,300])
title('theta'),xlabel('t (saniye)'),
text(4.05,0.23,'\theta_{Euler}')
set(h1(1),'LineWidth',2,'Color','yellow')
set(1,'color','green')
h=gca,set(h,'Color',[1 1 0.5]) % a��k sar�
set(h,'XTick',[0:4:10],'XTickLabel',[0:4:10])
figure(2), h2=plot(t,xE(2,:),'r',t,xR(2,:),'k')
set(2,'Name','A��sal h�zlar','Position',[400,150,400,200])
xlabel('t (saniye)'),ylabel('w (rad/s)')
legend(h2,'Euler','RungaKutta','Location','SouthEast')
axis([-2 5 -3 4])
% save 'sarkac50'  % T�m de�i�kenleri kaydeder
% save 'sarkac50tx' t xE xR