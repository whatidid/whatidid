%-- 19.02.2014 16:00 --%
simulink
s=tf('s')
help tf
H=tf([5 10],[1 1 0])
clear s
G=tf('(5*s+10)/(s^2+s)')
s=tf('s')
G=tf((5*s+10)/(s^2+s))
G=((5*s+10)/(s^2+s))
help zpk
Hzp=zpk(-2,[0 -1],5)
help step
help heaviside
[y,t]=step(H)
figure(1),plot(t,y)
[y,t]=step(Hzp)
figure(1),plot(t,y)
hel series
help series
A=series(H,Hzp)
sarkac