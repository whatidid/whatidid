%-- 17.12.2008 14:13 --%
% Tarihli derste kullan�lan komutlard�r. "mrc.mdl" modelini
% �al��t�rmadan �nce buradaki atamalar gerekmeMEkle beraber gidi� yolu
% hakk�nda yard�mc� olabilir.
A=[0 1; 0   -1];B=[0;1];K=[1 1];Ac=A-B*K
eig(Ac)
A=[0 1; 0   -1];B=[0;1];K=[0.1 0.2];Ac=A-B*K
eig(Ac)
A=[0 1; 0   -1];B=[0;1];K=[-1 0.2];Ac=A-B*K
eig(Ac)
A=[0 1; 0   -1];B=[0;1];K=[-1 2];Ac=A-B*K
eig(Ac)
A=[0 1; 0   -1];B=[0;1];K=[1 1];Ac=A-B*K
eig(Ac)
help poly
poly([3 4])
poly([-3 -4])
alfa1=7;alfa0=12;
k1=alfa0-0;k2=alfa1-1;
k1, k2