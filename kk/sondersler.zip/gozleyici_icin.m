%-- 31.12.2008 13:21 --%
% Tarihli derste kullan�lan komutlard�r. "gozleyici.mdl" modelini �al��t�rmadan �nce buradaki baz� atamalar gerekmektedir.
A=[1 -5;5 1];
eig(A)
L=[9;1];C=[1 0];Ao=A-L*C
eig(Ao)
B=[1;1];
C
L=[22;-96/5];C=[1 0];Ao=A-L*C
tx1
tx_bir
tx_iki
figure(1),plot(tx_bir(1),tx_bir(2),'y',tx_iki(1),tx_iki(2),'g',tx_uc(1),tx_uc(2),'r',tx_dort(1),tx_dort(2),'b')
figure(1),plot(tx_bir(:,1),tx_bir(:,2),'y',tx_iki(:,1),tx_iki(:,2),'g',tx_uc(:,1),tx_uc(:,2),'r',tx_dort(:,1),tx_dort(:,2),'b')
figure(1),plot(tx_bir(:,2),tx_bir(:,3),'y',tx_iki(:,2),tx_iki(:,3),'g',tx_uc(:,2),tx_uc(:,3),'r',tx_dort(:,2),tx_dort(:,3),'b')
xz1=-1.5:0.01:1.5;f1=-xz1/3;f2=-xz1;figure(1),plot(tx_bir(:,2),tx_bir(:,3),'y',tx_iki(:,2),tx_iki(:,3),'g',tx_uc(:,2),tx_uc(:,3),'r',tx_dort(:,2),tx_dort(:,3),'b',xz1,f1,':',xz1,f2,'.-')
xz1=-1.5:0.01:1.5;f1=-xz1/3;f2=-xz1;figure(1),plot(tx_bir(:,2),tx_bir(:,3),'y',tx_iki(:,2),tx_iki(:,3),'g',tx_uc(:,2),tx_uc(:,3),'r',tx_dort(:,2),tx_dort(:,3),'b',xz1,f1,':',xz1,f2,':')