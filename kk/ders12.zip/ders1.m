t=0:0.01:10;t=t'; % S�tuna �evirdik
x=cos(5*t); y=sin(5*t);
figure(1),plot(t,[x,y]),zoom on
set(1,'Name','sin cos')
set(1,'Position',[200 100 300 500])
figure(2),subplot(2,3,1),plot(t,x),
subplot(2,3,2),plot(t,y,'r'), % K�rm�z�(red) �izer  
subplot(2,3,3),plot(t,x.^2+y.^2),
subplot(2,3,4),plot(t,x.*y,':'), % Noktal� �izer. Di�er �izgi se�enekleri i�in help plot yaz�n�z.
figure(3),plot(1:10,10:10:100),text(5,30,'x^2 + \alpha'),text(10.2,5,'\beta_1') % �izim boyutlar�na g�re koordinatl� noktalara yaz� yaz�labilir