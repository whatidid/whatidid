function [t,x] = euler(t0,ts,x0,dt,dosyaismi)
% Bu program verilen bir dosyada kay�tl� uygun standarttaki
% bir diferansiyel denklemi Euler y�ntemiyle ��zer.

n=length(x0); % Dif. denklem merytebesi = x0 '�n mertebesidir.
nt=floor((ts-t0)/dt)+1; % t 'nin uzunlu�u (nokta say�s�)
% Boyutland�rma
t=zeros(1,nt);
x=zeros(n,nt);
% Ba�lang�� �artlar�
i=1; t(i)=t0; x(:,i)=x0;
for i=2:nt,
%     x(:,i)=x(:,i-1)+turev(t(i-1),x(:,i-1))*dt; % T�revin 'turev.m' sabit adl� fonksiyonda belirtilmesi hali
%     x(:,i)=x(:,i-1)+feval('turev',t(i-1),x(:,i-1))*dt; % Bu kullan�m fonksiyon ad�n�n buradaki 'turev' yerine yaz�lmas�n� gerektirir.
    x(:,i)=x(:,i-1)+feval(dosyaismi,t(i-1),x(:,i-1))*dt; % Bu kullan�mda ise t�revi i�eren fonksiyon ismi d��ar�dan verilir.
    t(i)=t(i-1)+dt; i=i+1;
end
end

% A�a��daki fonksiyon, istenirse 'turev.m' adl� bir dosyaya da yaz�labilir.
% O zaman 'turev' fonksiyonu d��ar�dan da tan�n�rd�. �imdi tan�nmaz.
function xd=turev(t,x) % Buradaki t ve x yukar�dakinden ba��ms�z
g=9.81; % Yer�ekimi ivmesi
l=1; % �p boyu
m=1; % K�tle
k=0.5; % S�rt�nme katsay�s�
xd=[x(2);
    -g/l*sin(x(1))-k/m/l*x(2)];
end