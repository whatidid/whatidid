%-- 22.10.2008 13:17 --%
eval('2*3')
metin='x=4+5';eval(metin)
metin='x=4+5;';eval(metin)
x
metin=['x' 'a'+2 '0'+5 ]
metin=['x' 'a'+2 '0'+5 '=x^2,']
metin=['x' 'a'+2 '0'+5 '=x^2,'],eval(metin)
xc5
metin=['x' 'a'+2 '0'+5 '=x^2,'];%Burada 2 ve 5 yerine de�i�ken tamsay� kullanarak de�i�ken say�da de�i�ken program i�inde �retilebilir
sin(2)
feval('sin',2)
ones(2,3)
feval('ones',2,3)
feval('ones',2)
ones(2)
help euler
zeros(3)
[t,x] = euler(0,50,[pi/6;0],0.001);
plot(t,x)
figure(5),plot(t,x)
clear all; close all
[t,x] = euler(0,50,[pi/6;0],0.001);
figure(5),plot(t,x)
clear all; close all
[t,x] = euler(0,50,[pi/6;0],0.001,'turev');  % Dosya ad�ndaki .m yaz�lmaz
figure(5),plot(t,x)
help ode
help ode23
help ode45
turev(1,[2;3])
clear all; close all
[t,x] = runga('trv',0,50,[pi/6;0],0.001);
figure(3),plot(t,x)
[t,x] = euler(0,50,[pi/6;0],0.001,'turev');  % Dosya ad�ndaki .m yaz�lmaz
figure(5),plot(t,x)
[t,x] = euler(0,50,[pi/6;0],0.001/4,'turev');  % Dosya ad�ndaki .m yaz�lmaz
figure(4),plot(t,x)
figure(4),plot(t,x),axis([0 50 -1.5 1.5])
simulink
a=5
to=1/4
to=0.1;
to=1;
to=10;
h
h=0