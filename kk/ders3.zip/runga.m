function [t,x] = runga(dosyaismi,t0,ts,x0,dt)
% Bu program verilen bir dosyada kay�tl� uygun standarttaki
% bir diferansiyel denklemi Euler y�ntemiyle ��zer.

n=length(x0); % Dif. denklem merytebesi = x0 '�n mertebesidir.
if nargin < 5, dt=0.001; end
nt=floor((ts-t0)/dt)+1; % t 'nin uzunlu�u (nokta say�s�)
% Boyutland�rma
t=zeros(1,nt);
x=zeros(n,nt);
% Ba�lang�� �artlar�
i=1; t(i)=t0; x(:,i)=x0;
for i=2:nt,
    % 4 ad�m Runga-Kutta metodu
    k1=feval(dosyaismi,t(i-1),x(:,i-1))*dt;
    k2=feval(dosyaismi,t(i-1)+0.5*dt,x(:,i-1)+0.5*k1)*dt;    
    k3=feval(dosyaismi,t(i-1)+0.5*dt,x(:,i-1)+0.5*k2)*dt;
    k4=feval(dosyaismi,t(i-1)+dt,x(:,i-1)+k3)*dt;
    dx=(k1+2*k2+2*k3+k4)/6;
    x(:,i)=x(:,i-1)+dx;
    t(i)=t(i-1)+dt;
end
end
