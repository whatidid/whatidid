A=[0 1 0;
   0 0 1;
   -6 -11 -6];
eig(A)  % A n�n �zde�erleri
[Vhazir,D]=eig(A) % Modal matrisi (V) ve k��egen matrisi verir
                  % Ama �ak���k �zde�er varsa V yanl�� olabilir
[Vgenel,Jhazir]=jordan(A)    % Bu ise �ak���k olsa bile genelle�tirilmi� �zvekt�rlerle kurulan V matrisini ve
                             % Jordan blok k��egen matrisi verir.
% Ad�m ad�m kendimiz yapal�m
lmd=eig(A);lmd=round(lmd)   % !Tamsay� de�ilse d�zeltin
syms L, % Sembolik lambda
adjointA=det(L*eye(3)-A)*inv(L*eye(3)-A),   % det*inv => adjoint
L=lmd(1); sonuc=eval(adjointA)
v1=sonuc(:,3);  % Ekranda g�r�p en ho�uma gideni ald�m
%if abs(sonuc(:,3)) > 1e-5, v1=sonuc(:,3); end
L=lmd(2); sonuc=eval(adjointA)
v2=sonuc(:,3);  % Ekranda g�r�p en ho�uma gideni ald�m
L=lmd(3); sonuc=eval(adjointA)
v3=sonuc(:,2);  % Ekranda g�r�p en ho�uma gideni ald�m

V=[v1,v2,v3]
kosegen=inv(V)*A*V
syms t
eLt=diag([exp(lmd(1)*t) exp(lmd(2)*t) exp(lmd(3)*t)])
eAt=V*eLt*inv(V)

% Bu i�lemi haz�r yapan expm fonksiyonu normalde sabit i�in ama sembolik de
% olur.
eAthazir=expm(A*t)
eAthazir-eAt    % Sembolik sa�lama s�f�r olmal�
% Emin olmak i�in
t=1.2362; % �zel olmayan rasgele bir noktaicin sa�lama yapal�m:
eval(eAthazir-eAt)