% DC jenerat�r deney grafikleri verir. Seri ve ��nt sarg�lar ile 
% histerezis etkisi de hesaba kat�lm��t�r. Armat�r reaksiyonu ise ters
% y�nde zay�f bir seri sarg� gibi k�smen hesaba kat�lm��t�r.
% Jenerat�r�n sabit h�zda tutulmas� i�in gereken tork giri�i i�in PI
% kontrol de i�erir.
% (This program gives DC generator experimental graphics. Series and shunt
% windings with hysteresis effect are taken into account. Armature reaction
% is partially taken into account as if a weak series winding in opposite
% direction.

%% �lk �al��ma m� yoksa �ncekiyle kar��la�t�rma m� (First running or comparison with previous)?
   % A�a��daki 2 komut sat�r�ndan birini aktif di�erini inaktif ediniz:
   % (Deactivate one of the following two command lines.)
clear all, clear functions, close all, clc % �lk �al��ma i�in �nceki t�m bilgileri silmek iyi olabilir.
                           % (It may be a good to clear all previous information for the first operation.)
% figure(2),hold on, figure(3),hold on, figure(4),hold on, figure(5),hold on % �nceki �al��mayla kar��la�t�rmal� grafikler i�in
                                                        % (For comparative plots with the previous operations)
%% Anma de�erleri (Rated values)
vDC_=200; % V;  Beklenen gerilim, uygulanan de�il (Expected voltage, not applied)
nr_=1500;% rpm
ia_=8.5;% A; Ak�m y�n� motordakinin tersi (Current direction is opposite to that of the motor)
TL_=8.1;% Nm; Giri� torku (Input torque)
H_=1422; % A/m;  Anma �al��mas�nda �retilen net manyetik alan.
         % Bunun T cinsinden manyetik ak� yo�unlu�u (B) kar��l���, "clear functions,BHisterezis(H_)" komutuyla g�r�lebilir.
         % (Magnetic field produced at rated operation.
         % Corresponding magnetic flux density to this in T can be seen with "clear functions,BHisterezis(H_)" command.)
         % 1422A/m --> 1.43T (mu_r = mu/mu0 = 800)
vF_=200; % V; Sadece yabanc� uyart�ml� i�in (Only for separately excited)
Ry_=vDC_/ia_; % Yakla��k anma y�k direnci (Rated load resistance approximately)
%% Makine parametreleri (Machine parameters)
Ra=2.; % ohm
La= 0.1; % H
Kb=1.15; % Vs/rad veya(or) Nm/A;  Anma de�erlerinde �al��ma i�in z�t emk sabiti (Back emf constant for operation at rated values)
Bf=0.012; % Nm.s/rad
Ji= 0.0061; % kg.m^2
% A�a��dakileri elinizdeki motor de�erlerinize g�re veya istedi�iniz kay�p ve zaman sabiti de�erlerine g�re atay�n.
% (Assign the following according to your motor values or the desired loss and time constant values.)
% Yabanc� uyart�m i�in ��nt sarg� kullan�l�yor (Shunt winding is used for separate excitation).
Rshunt=470; % ohm
Lshunt=Rshunt*0.1; % H;  ��nt sarg� zaman sabiti 0.1s (Shunt winding time constant is 0.1s)
Rseri=Ra/4; % ohm; 
Lseri=La/4; % H

% Anma manyetik ak�s�na her sarg�n�n katk� oran� (contribution rate of each winding to the rated magnetic flux)
% Toplam� 1 olmal�, yoksa yukar�dakinden ba�ka Kb varsay�lm�� olur (Total must be 1, otherwise assumed Kb becomes different from above.)
kseri=0.25;  % ��karmal� kompunda g�re tasar�m i�in eksi girin. (Enter negative for a design according to differential compounding.)
             % Ancak ba�ka tasar�m� ��karmal� kompund i�in kullan�rken de�i�tirmeyin.
             % (However, do not change when another design is used for differential compounding.)
kshunt=1.05;
karmatur=-0.05; % Armat�r reaksiyonu negatif etkili
kpm=0*(1+karmatur); % Sabit m�knat�sl�ysa 0 �arpan�n� kald�r�n (Remove 0 coefficient if pm).
%% Kontrol parametreleri (Control parameters)
Kp=1;   % Nm.s/rad
Ki=10;  % Nm/rad
%% Sim�lasyon parametreleri (Simulation parameters)
t0=0; % Ba�lang�� an� (Initial time)
dt=0.001; % Diferansiyel denklem n�merik ��z�m zaman ad�m� (Time step for differential equation numerical solution)
x0=[1 0 0]; % [ia wr ishunt] vekt�r�n�n ba�lang�� �artlar� (Initial condition of [ia wr ishunt] vector)
            % Kendinden uyart�ml� jenerat�rde ishunt ba�lang�� ak�m� s�f�rdan farkl� olmal�.
            % (ishunt or ia initial current must be nonzero for the self-excited generator.)

% A�a��daki s�reler dt 'nin tam kat� olmal� (The following times must be integer multiple of dt).
durulma_suresi=3; % s; (Settling time after each step change in load)
olcum_suresi=1; % s; (Measurement time after settling)
kademe_suresi=durulma_suresi+olcum_suresi; % (Total operation time at each load step)
Ryukleme=([5 4 3 2.2 1.5 1.2 1 0.9 0.8])'*Ry_; % Y�k direnci kademeleri (Load resistance steps)
ts=kademe_suresi*length(Ryukleme); % Sim�lasyon biti� an� (Simulation end time)

uyartim='seri'; % 'seri' , 'sont' , 'eklemeli'=eklemeli kompund,
                % 'cikarmali' = ��karmal� kompund, ��nt-seri,
                % 'yabanci' = yabanc� uyart�ml�,  'pm' = sabit m�knat�sl�
                % (excitation type ('sont' for shunt, 'eklemeli' for cumulative compounding
                % 'cikarmali' for differential compounding
                % 'yabanci' for separateley excited,  'pm' for permanent magnet)
% Yabanc� uyart�ml�n�n ��ntten fark� sonra hesaba kat�lacak (Difference of separately excited from shunt will be accounted later).
cseri=0; cshunt=0; % varsay�lan kat�l�m (default attendance)
if strcmp(uyartim,'seri'), cseri=1;
elseif strcmp(uyartim,'sont')||strcmp(uyartim,'yabanci'), cshunt=1;
elseif strcmp(uyartim,'eklemeli'), cseri=1; cshunt=1;
elseif strcmp(uyartim,'cikarmali'), cseri=-1; cshunt=1;
end % E�er(if) 'pm' ise(then) cseri=0; csont=0;
%% Boyutland�rma ve ba�lang�� de�erleri (Dimensioning and initial values)
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s� (number of simulation steps)
t=zeros(nt,1); % �imdilik s�f�r olsun (let it be zero now)
vDC=t; TL=t; Ry=t; % �imdilik s�f�r olsunlar (let them be zero now)
x=zeros(nt,3); % �imdilik s�f�r olsun (i. sat�r� t(i) an�n�n [ia wr ishunt] vekt�r�)
               % (let it be zero now (i-th row is [ia wr ishunt] vector at t(i)) )
t(1)=t0;
x(1,:)=x0';
vF=t+vF_;
Nolc=length(Ryukleme);
Nkademe=kademe_suresi/dt; % bir y�k kademesinde sim�lasyon ad�m say�s� (number of simulation steps during each load step)
for j=1:Nolc;
    Ry((j-1)*Nkademe+1:j*Nkademe)=zeros(Nkademe,1)+Ryukleme(j);
end
Ry(end)=Ry(end-1);
% Her y�k de�i�iminde (kademe_suresi-olcum_suresi) beklenip sonraki olcum_suresi i�inde ortalamas� �l��m olarak al�nacak.
% ((load steptime - measurement time) is waited for settling, then the average will be taken as a measurement during the next measurement time.)
olcum_indisleri=[(1:Nolc)'/dt*kademe_suresi-olcum_suresi/dt (1:Nolc)'/dt*kademe_suresi]; % �l��m ba�lang�� ve biti� indisleri
                                                                                        % (Indexes for measurement start and end times)
ia_olcumleri=zeros(Nolc,1); % A;  (ia measurements for each load step)
ishunt_olcumleri=zeros(Nolc,1); % A;  (ishunt measurements for each load step)
iy_olcumleri=zeros(Nolc,1); % A;   (terminal current measurements for each load step)
nr_olcumleri=zeros(Nolc,1); % rpm;   (nr (rpm speed)measurements for each load step)
vDC_olcumleri=zeros(Nolc,1); % V;   (vDC measurements for each load step)
 % �u ikisi, yabanc� uyart�ml� i�in (Following two is for separately excited)
vF_olcumleri=zeros(Nolc,1); % V;   (vF voltage measurements for each load step)

int_wr=0; Kbd=0;
%% Baz� �n hesaplamalar (Some pre-calculations)
% Rated values
Iseri_=ia_; Ishunt_=vDC_/Rshunt; % Kompund i�in biraz de�i�tirilebilir (They can be changed a little bit for compound).
if strcmp(uyartim,'yabanci')
   Ishunt_=vF_/Rshunt; % Yabanc� uyart�m i�in ��nt sarg� kullan�l�yor (Shunt winding is in use for separate excitation).
end

KbB=Kb/BHisterezis(H_); % Kb/B oran�, anma manyetik de�erlerinde (Kb/B ratio at rated magnetic values)
                        % KbB*B de�i�ken Kb yani Kbd olacak (KbB*B will be Kbd).
K_shunt=kshunt*H_/Ishunt_; % manyetik alan� i�in o ak�m�n katsay�s� (coefficient of that current for its magnetic field)
K_seri=kseri*H_/Iseri_; % manyetik alan� i�in o ak�m�n katsay�s� (coefficient of that current for its magnetic field)
K_armatur=karmatur*H_/ia_; % armat�r reaksiyonu manyetik alan� i�in armat�r ak�m�n�n katsay�s� (coefficient of armature current for armature reaction magnetic field)
K_pm=kpm*H_; % Sabit m�knat�s�n manyetik alan� (Magnetic field of PM)

%% D�ng� ba�l�yor (Loop starting)
for i=1:nt-1
    % A�a��daki "if" komut b�lgesini sadece gerekirse aktifle�tirin.
    % (Activate the following "if" command area only in necessity.)
    if strcmp(uyartim,'cikarmali') % ��karmal� kompund ise (if differential compounding)
       % ��karmal� kompundda artan gerilimle kalk��ta seri sarg� ak�s� y�ksek, ��nt sarg� ak�s� d���kt�r. Sonradan tersi olmaya meyledebilir. Bu durumda ak� i�aret de�i�tirmeye yani s�f�ra gitmeye �al��abilir ki bu istenmez.
       % Kalk�� s�ras�nda seri sarg� k�sa devre ile iptal, sonra k�sa devresi a��l�p devreye al�n�yor.
       % (In differential compounding, series winding magnetic field is high and shunt winding magnetic field is low while starting up with increasing voltage. It may tend to opposite later. In this case the flux may tend to change sign, i.e., approaches zero, which is unwanted.
       % Series winding is disabled with a short circuit at the start up, then enabled removing the short circuit.)

       %if t(i)<durulma_suresi*0.75, cseri=0; else cseri=-1; end 
    end
    t(i+1)=t(i)+dt;
    iy=x(i,1); % iy=ia
    if strcmp(uyartim,'sont')||strcmp(uyartim,'eklemeli')||strcmp(uyartim,'cikarmali')
       iy=x(i,1)-x(i,3); % iy=ia-ishunt
    end
    vDC(i)=Ry(i)*iy; % Terminal u�lar�na de�i�ken y�k direnci ba�l�, kaynak de�il (Variable load resistance Ry(i) is connected to the terminal).
    if vDC(i)>10*vDC_, vDC(i)=10*vDC_; end
    if vDC(i)<-10*vDC_, vDC(i)=-10*vDC_; end
    %% De�i�ken y�kte sabit h�z i�in kontrol (Control for constant speed at variable load)
    wref=pi*nr_/30;
    err_wr=wref-x(i,2); % H�z hatas� (rad/s) (Speed error)
    prop_wr=Kp*err_wr;
    int_wr=int_wr+Ki*dt*err_wr; % Hata integrali (error integral)
    TL(i+1)=prop_wr+int_wr; % PI control
%     if TL(i+1)>1.8*TL_, TL(i+1)=1.8*TL_; end % Max input tork 1.8*TL_
%     if TL(i+1)<0*TL_, TL(i+1)=0*TL_; end % Min input tork 0*TL_
%     int_wr=TL(i+1)-prop_wr;
    %%
    magneticField=cseri*K_seri*x(i,1)+cshunt*K_shunt*x(i,3)+K_pm; % Armat�r raksiyonu hari� (Except the armature reaction)
    Kbd=KbB*BHisterezis(magneticField+sign(magneticField)*K_armatur*x(i,1)); % Kb yerine de�i�ken B 'ye ba�l� Kbd, armat�r reaksiyonu dahil
                                                                             % (Kbd is variable B-dependant instead of Kb including the armature reaction)
    if strcmp(uyartim,'pm'), Kbd=Kb; end % (Design value for pm motor)
    if strcmp(uyartim,'yabanci') % (Separate excitation)
       A=[-(Ra+abs(cseri)*Rseri+Ry(i))/(La+abs(cseri)*Lseri)  Kbd/(La+abs(cseri)*Lseri)  0;
            -Kbd/Ji    -Bf/Ji     0;
             0   0  -(Rshunt+Ry(i))/Lshunt];
       b=[0;TL(i)/Ji;vF(i)/Lshunt];
    else
       A=[-(Ra+abs(cseri)*Rseri+Ry(i))/(La+abs(cseri)*Lseri)  Kbd/(La+abs(cseri)*Lseri)  cshunt*Ry(i)/(La+abs(cseri)*Lseri);
            -Kbd/Ji    -Bf/Ji     0;
             Ry(i)/Lshunt   0  -(Rshunt+Ry(i))/Lshunt];
       b=[0;TL(i)/Ji;0];
    end
    eAdt=expm(A*dt);eAb=(eAdt-eye(3))*inv(A)*b;
    x(i+1,:)=(eAdt*x(i,:)'+eAb)';
%     res=x(i+1,:),pause
end
Ry(i+1)=Ry(i); vDC(i+1)=vDC(i); vF(i+1)=vF(i);

%% Her y�k kademesindeki �l��mler (Measurements at each load step)
for j=1:Nolc
    ia_olcumleri(j)=mean(x(olcum_indisleri(j,1):olcum_indisleri(j,2),1)); % (ia measurements)
    TL_olcumleri(j)=mean(TL(olcum_indisleri(j,1):olcum_indisleri(j,2),1)); % (ia measurements)
    nr_olcumleri(j)=mean(x(olcum_indisleri(j,1):olcum_indisleri(j,2),2))*30/pi; % (nr (rpm speed) measurements)
    ishunt_olcumleri(j)=mean(x(olcum_indisleri(j,1):olcum_indisleri(j,2),3)); % (ishunt measurements)
    if strcmp(uyartim,'yabanci')||strcmp(uyartim,'pm') % (terminal current measurements)
       iy_olcumleri(j)=ia_olcumleri(j); % Yabanc� uyart�ml� ya da sabit m�knat�sl� (Separately excited or permanent magnet)
    else
       iy_olcumleri(j)=ia_olcumleri(j)-cshunt*ishunt_olcumleri(j);
    end
    vDC_olcumleri(j)=mean(vDC(olcum_indisleri(j,1):olcum_indisleri(j,2))); % (terminal voltage measurements)
    if strcmp(uyartim,'yabanci')
       vF_olcumleri=mean(vF(olcum_indisleri(j,1):olcum_indisleri(j,2))); %(separate excitation voltage)
    end
end
%% �l��mlerden hesaplamalar (Calculations from measurements)
wr_hesap=pi/30*nr_olcumleri;
E_hesap=vDC_olcumleri+(Ra+abs(cseri)*Rseri)*ia_olcumleri;
Pm_hesap=E_hesap.*ia_olcumleri;
Tm_hesap=Pm_hesap./wr_hesap;
Ti_hesap=Tm_hesap+Bf*wr_hesap;
Pi_hesap=Ti_hesap.*wr_hesap;
if strcmp(uyartim,'yabanci')
   Pi_hesap=Pi_hesap+vF_olcumleri.*ishunt_olcumleri;
end
Po_hesap=vDC_olcumleri.*iy_olcumleri;
verim_hesap=Po_hesap./Pi_hesap; % (Efficiency)
% if isnan(verim_hesap(1)), verim_hesap(1)=verim_hesap(2); end
% if isnan(verim_hesap(end)), verim_hesap(end)=verim_hesap(end-1); end

%% �izimler (plots)
% �izim s�n�rlar� ve indisleri(bt) (Plot ranges and indexes(bt))
if nt>5000, bt=1:floor(nt/5000):nt; else bt=1:nt; end % �ok uzun sinyallerden atlanarak 5-10 bin civar� nokta �izilecek. (Only 5-10 thousand points will be plotted from very long signals by jumping.)
if exist('nrmin','var')==0, nrmin=0; end, nrmin=min([nrmin;1.1*nr_olcumleri]);
if exist('nrmax','var')==0, nrmax=0; end, nrmax=max([nrmax;1.1*nr_olcumleri]);
wrmin=nrmin*pi/30; wrmax=nrmax*pi/30;
if exist('vDCmin','var')==0, vDCmin=0; end, vDCmin=min([vDCmin;1.1*vDC_olcumleri]);
if exist('vDCmax','var')==0, vDCmax=0; end, vDCmax=max([vDCmax;1.1*vDC_olcumleri]);
if exist('iymin','var')==0, iymin=0; end, iymin=min([iymin;1.1*iy_olcumleri]);
if exist('iymax','var')==0, iymax=0; end, iymax=max([iymax;1.1*iy_olcumleri]);
if exist('Pomin','var')==0, Pomin=0; end, Pomin=min([Pomin;1.1*Po_hesap]);
if exist('Pomax','var')==0, Pomax=0; end, Pomax=max([Pomax;1.1*Po_hesap]);
if exist('Timin','var')==0, Timin=0; end, Timin=min([Timin;1.1*Ti_hesap]);
if exist('Timax','var')==0, Timax=0; end, Timax=max([Timax;1.1*Ti_hesap]);

figure(1),set(1,'Name','ia & TL && wr & vDC zamana g�re(with respect to time)'),
subplot(2,1,1),plot(t(bt),x(bt,1),t(bt),TL(bt)),grid
subplot(2,1,2),plot(t(bt),x(bt,2),t(bt),vDC(bt)),grid
figure(2),set(2,'Name','Po''nun Iy ''ye g�re de�i�imi (Po with respect to terminal current Iy)')
plot(iy_olcumleri,Po_hesap),xlabel('Iy (A)'),ylabel('Po (W)')
axis([iymin iymax Pomin Pomax]),grid
figure(3),set(3,'Name','verim''in Iy ''ye g�re de�i�imi (efficiency with respect to terminal current Iy)')
plot(iy_olcumleri,verim_hesap),xlabel('Iy (A)'),ylabel('verim(efficiency)')
axis([iymin iymax 0 1.1]),grid
figure(4),set(4,'Name','Ti''nin Iy ''ye g�re de�i�imi (Ti with respect to terminal current Iy)')
plot(iy_olcumleri,Ti_hesap),xlabel('Iy (A)'),ylabel('Ti (Nm)')
axis([iymin iymax Timin Timax]),grid

figure(5),set(5,'Name','vDC ''nin Iy ''ye g�re de�i�imi (vDC variation with respect to terminal current Iy)'),
plot(iy_olcumleri,vDC_olcumleri),xlabel('Iy (A)'),ylabel('vDC (V)')
axis([iymin iymax vDCmin vDCmax]),grid