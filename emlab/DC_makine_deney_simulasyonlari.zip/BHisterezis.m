function [B,Bas]=BHisterezis(H)
% Bu program, �nceki �al��madan kalan art�k m�knat�siyeti de dikkate alarak
% verilen H manyetik alan� i�in B manyetik ak� yo�unlu�unu verir.
% �stenen malzeme i�in s�f�rdan ba�layan Href ve Bref tablo de�erleri
% program i�inde de�i�tirilebilir.
% Buradaki modelleme m�kemmele yak�n de�ildir fakat normal AC �al��malarda
% olduk�a iyi sonu�lar verir. Anormal de�i�imler gibi baz� sorunlu
% durumlarda referans e�rinin takip edildi�i varsay�l�r.
% (This program find B magnetic flux density for a given H magnetic field
% also taking remanence into account from previous operation.
% Href and Bref table values which are starting from zero can be changed in
% the program for a desired material.
% The modeling here is not excellent, but gives quite good results for
% usual AC operations. In some problematic cases like abnormal changes, the
% reference curve is assumed to be followed.)

persistent Hson Bson Bsonas BH kart Bmax
kart=0.05; % art�k m�knat�siyet oran� (remanence ratio)
mu0=4e-7*pi;
if isempty(Hson),
   Href=[0, 48.2849825077384, 71.1530115391793, 104.851462880476, 154.509683151251, 227.686305289931, 335.519771701505, 494.423751394627, 728.58551585036, 1073.64755922343, 1582.13285379556, 2331.4395357726, 3435.62191754218, 5062.75105109458, 7460.49734823436, 10993.8292681759, 16200.5663076076]';
   Bref=[0, 0.0607187658713759, 0.0894434019281584, 0.13170170269561, 0.193749066921123, 0.284469108379353, 0.415911266976597, 0.602688124797218, 0.857467986679896, 1.17733480144963, 1.5201843897251, 1.80012483588549, 1.95167752832168, 1.9994705688458, 2.00903594034407, 2.01381125292058, 2.02035822721997]';
   Bref=Bref+mu0*Href;
   Href=[-Href(end:-1:2); Href]; Bref=[-Bref(end:-1:2); Bref];
   BH=spline(Href,Bref);
   Hmax=max(Href); Bmax=max(Bref);
   B=ppval(BH,H); Bas=B;
   if nargin<2, Bson=B; Hson=H; Bsonas=Bas; end
else
   Bas=ppval(BH,H); B=Bas;
   dH=H-Hson;
   if (H<0)&&(dH>0) % Solda ��k��, normalde 3. b�lgede (Increase on the left, normally in the 3rd quarter)
      if (Bson<=Bsonas) % normal ��k��(3. b�lgede) (normal increase(in the 3rd quarter))
         B=Bson+(Bas-Bsonas)*(1-kart*((H<=-500)-(H>-500)*H*0.002));
      else B=Bson+(Bas-Bsonas)*0.25; % anormal ��k��(3. ya da 2. b�lgede) (abnormal increase(in the 3rd or 2nd quarter))
      end
   elseif (H>=0)&&(dH>0) % Sa�da ��k��, normalde 4. ya da 1. b�lgede (Increase on the right, normally in the 4th or 1st quarter)
      if (Bson>Bas), B=Bson+(Bas-Bsonas)*0.25; % anormal ��k��(1. b�lgede) (abnormal increase(in the 1st quarter))
      else % normal ��k��(4. ya da 1. b�lgede) (normal increase(in the 4th or 1st quarter))
         B=Bson+(Bas-Bsonas)*(1+kart*((H>=500)+(H<500)*H*0.002));
         if B>Bas,B=Bas; end  % fazla ��k�yorsa as�l e�riye gelsin (if increasing too much, let it come to the reference curve)
      end
   elseif (H>=0)&&(dH<=0) % Sa�da ini�, normalde 1. b�lgede (Decrease on the right, normally in the 1st quarter)
      if (Bson>=Bas) % normal ini�(1. b�lgede) (normal decrease(in the 1st quarter))
         B=Bson+(Bas-Bsonas)*(1-kart*((H>=500)+(H<500)*H*0.002));
      else B=Bson+(Bas-Bsonas)*0.25; % anormal ini�(1. ya da 4. b�lgede) (abnormal decrease(in the 1st or 4th quarter))
      end
   elseif (H<0)&&(dH<=0) % Solda ini�, normalde 2. ya da 3. b�lgede (Decrease on the left, normally in the 2nd or 3rd quarter)
      if (Bson<=Bas), B=Bson+(Bas-Bsonas)*0.25; % anormal ini�(3. b�lgede) (abnormal decrease(in the 3rd quarter))
      else % normal ini�(2. ya da 3. b�lgede) (normal decrease(in the 2nd or 3rd quarter))
         B=Bson+(Bas-Bsonas)*(1+kart*((H<=-500)-(H>-500)*H*0.002));
         if B<Bas,B=Bas; end % fazla iniyorsa as�l e�riye gelsin (if decreasing too much, let it come to the reference curve)
      end
   end
   if B>Bmax, B=Bmax; elseif B<-Bmax, B=-Bmax; end % Doyma (mu0 ile de�i�im ihmal) (Saturation (change with mu0 is neglected))
end
if nargin<2, Bson=B; Hson=H; Bsonas=Bas; end
% B=1000*mu0*H;
end
