disp('-----------------------------')
r1=4;   % faz ba��na armat�r direnci ohm (do�rudan tek faz �l��m�)
% ADK If    Vt
adk=[0      4;
   0.20   65 ;
   0.40  128;
   0.60  183;
   0.79  232;
   1     275;
   1.21  314;
   1.39  346;
   1.62  380;
   1.81  399;
   2     421
   ];
%  KDK
%   If    Ia
kdk=[0      0.02;
   0.21   0.29;
   0.40   0.53;
   0.62   0.80;
   0.81   1.04;
   1      1.29;
   1.20   1.54;
   1.39   1.78;
   1.60   2.04;
   1.80   2.30;
   1.98   2.52
   ];
figure(1),set(1,'Name','ADK fazlar aras� gerilim')
plot(adk(:,1),adk(:,2)),axis([0 2 0 440])
xlabel('If (A)'),ylabel('ADK fazlararas� Vt (V)')
figure(2),set(2,'Name','KDK hat ak�m�=faz ak�m�')
plot(kdk(:,1),kdk(:,2)),axis([0 2 0 2.6])
xlabel('If (A)'),ylabel('KDK ak�m� Ia (A)')
figure(3),set(3,'Name','ADK tek faz Vt ve KDK 100*Ia')
plot(adk(:,1),adk(:,2)/sqrt(3),kdk(:,1),kdk(:,2)*100),axis([0 2 0 300])
hold on

[mn,nv_anma]=min(abs(adk(:,2)-380)); % anma geriliminin(380) indisi nv_anma
[mn,nif_vanma_kdkda]=min(abs(kdk(:,1)-adk(nv_anma,1))); % adk'da anma gerilimini veren if de�erine kdk'da en yak�n if de�erinin kdk'daki indisi
[mn,ni_anma]=min(abs(kdk(:,2)-2.3)); % anma ak�m�na (2.3) en yak�n de�erin indisi ni_anma
ia_vanma=kdk(nif_vanma_kdkda,2)/kdk(nif_vanma_kdkda,1)*adk(nv_anma,1) % adk'da anma gerilimini veren uyart�m ak�m�ndaki kdk ia de�erinin en yak�n �l��mden tahmini
nhad=2; % hava aral��� do�rusall��� �zerinde bulunan bir noktan�n adk'daki indisi 2 al�ns�n. kdk'da da 2. uyart�m ak�m�n�n buna yak�n oldu�ud���n�l�yor.
ia_nhad_kdkda=kdk(nhad,2)/kdk(nhad,1)*adk(nhad,1); % nhad. uyart�m ak�m�nda kdk'daki armat�r ak�m�

plot([0 adk(nv_anma,1)],[380/sqrt(3) 380/sqrt(3)],'k:'),
plot([adk(nv_anma,1) adk(nv_anma,1)],[380/sqrt(3) 0*100*ia_vanma],'k:'),
plot([adk(nv_anma,1) 2],[100*ia_vanma 100*ia_vanma],'k:'),
plot([0 adk(nhad,1)],[adk(nhad,2)/sqrt(3) adk(nhad,2)/sqrt(3)],'k:')
plot([adk(nhad,1) adk(nhad,1)],[adk(nhad,2)/sqrt(3) 100*kdk(nhad,2)/kdk(nhad,1)*adk(nhad,1)],'k:')
plot([adk(nhad,1) 2],[100*ia_nhad_kdkda 100*ia_nhad_kdkda],'k:')
plot([kdk(ni_anma,1) kdk(ni_anma,1)],[0 100*kdk(ni_anma,2)],'r:')
plot([kdk(ni_anma,1) 2],[100*kdk(ni_anma,2) 100*kdk(ni_anma,2)],'r:')
text(0.2,280,'Ye�il ve mavi �izgilerin kesi�mesinin hi� bir anlam� yoktur;')
text(0.2,260,'��nk� mavisi gerilim, ye�ili ak�m boyutundad�r.')
text(0.2,240,'K�rm�z� kesikli �izginin k��esi ye�il do�ru �zerindedir.')
hold off
xlabel('If (A)'),ylabel('ADK tek faz Vt ve KDK 100*Ia')

zs_doymus=adk(nv_anma,2)/sqrt(3)/ia_vanma
zs_doymamis=adk(nhad,2)/sqrt(3)/ia_nhad_kdkda,
xs_doymus=sqrt(zs_doymus^2-r1^2),
xs_doymamis=sqrt(zs_doymamis^2-r1^2),
kdo=adk(nv_anma,1)/kdk(ni_anma,1)
