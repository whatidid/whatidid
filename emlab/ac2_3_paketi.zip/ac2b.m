close all
vh=380;
p1=300;% P=300W
%   If      Ia
pv1=[ 0.56    1.26;
    0.87    0.95;
    1.19    0.65;
    1.55    0.47;
    1.74    0.49;
    1.96    0.59;
    2.13    0.70
    ];
p2=600;% p=600w
%    If      Ia
pv2=[ 0.47    2.06;
    0.80    1.37;
    1.17    0.98;
    1.52    0.82;
    2       0.95;
    2.22    1.06;
    ];
p3=900;% p=900w
%  If      Ia
pv3=[0.92   1.90;
   1.20   1.52;
   1.43   1.34;
   1.67   1.31;
   2.10   1.38;
   2.32   1.46
   ];
pv1(:,3)=p1./(sqrt(3)*vh*pv1(:,2)); % 3. s�tun cos fi = p/(kok3*vh*ia)
pv2(:,3)=p2./(sqrt(3)*vh*pv2(:,2)); % 3. s�tun cos fi = p/(kok3*vh*ia)
pv3(:,3)=p3./(sqrt(3)*vh*pv3(:,2)); % 3. s�tun cos fi = p/(kok3*vh*ia)
figure(1),set(1,'Name','V e�rileri ailesi'),
plot(pv1(:,1),pv1(:,2),pv2(:,1),pv2(:,2),pv3(:,1),pv3(:,2))
axis([0 2.5 0 2.5]), xlabel('If (A)'),ylabel('Ia (A)')
legend('P_1=300W','P_2=600W','P_3=900W sabit','Location','NorthEast')
figure(2),set(2,'Name','cos fi e�rileri ailesi'),
plot(pv1(:,1),pv1(:,3),pv2(:,1),pv2(:,3),pv3(:,1),pv3(:,3))
axis([0 2.5 0 1.3]), xlabel('If (A)'),ylabel('cos fi')
legend('P_1=300W','P_2=600W','P_3=900W sabit','Location','SouthEast')
if max([pv1(:,3);pv2(:,3);pv3(:,3)])>1,
    text(0.2,1.2,'�l��m hatalar�ndan dolay� 1''den b�y�k baz� de�erler bulundu.');
end
