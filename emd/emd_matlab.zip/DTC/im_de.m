function xd=im_de(t,x)
% Induction motor model
% General reference frame rotating with wg.
%
% btu=Lr/(Lr*Ls-M^2);  M2_Lr=M^2/Lr;   M_Lr=M/Lr;   a33=Rr/Lr;
% gm1=3*np*M/2/Ji/Lr;  gm2=Bf/Ji;      gm3=1/Ji;
% gm1Ji=gm1*Ji; bir_dt=1/dt;
global wg vdn vqn TL i bir_dt dt trq_ref c_elk;
global btu Rs M2_Lr M_Lr M a33 gm1 gm2 gm3 Bf gm1Ji TCoulomb;

%*****************
% Coulomb s�rt�nmesini dikkate almak
c_elk=1;
Tfark=gm1Ji*(x(2)*x(3)-x(1)*x(4)) - TL(i) ;%+ 0*max(10,(1-c_elk)*trq_ref);  % Te-TL
                                                                 % Benzinli motordan tork talebi max(10,(1-c_elk)*trq_ref)
                                                                 % ancak bunun 1/(1+s.tau_benz) gecikmesiyle ger�ekle�ece�i kabul ediliyor.
if x(5)==0
    if abs(Tfark)<TCoulomb, Tsur=Tfark; % T�revi s�f�r yapacak (h�z s�f�rda KALACAK) �ekilde
    else Tsur=sign(Tfark)*TCoulomb; % H�z s�f�r oldu�u i�in yaln�z -+TCoulomb var
    end
    wrd=(Tfark-Tsur)*gm3; % H�z�n t�revi
else
    Tsur=sign(x(5))*TCoulomb+Bf*x(5); % E�er bu ad�mda h�z s�f�ra ula��yorsa GE��C� (h�z s�f�rlanana kadar)
    wrd=(Tfark-Tsur)*gm3; % H�z�n t�revi (ge�ici olabilir)
    Dt=-x(5)/wrd; % H�z�n s�f�ra ula�ma s�resi (de�er ger�ek�i ise)
    if 0<Dt && Dt<dt
       % H�z�n s�f�ra ula�mas�ndan sonraki dt-Dt s�resi i�in hesap yapal�m
       % �nce Tsur, h�z�n s�f�r oldu�u durumdaki gibi hesaplanacak
       if abs(Tfark)<TCoulomb, Tsur=Tfark; % T�revi s�f�r yapacak (h�z s�f�rda KALACAK) �ekilde
       else Tsur=sign(Tfark)*TCoulomb; % H�z s�f�r oldu�u i�in yaln�z -+TCoulomb var
       end
       wrd=( gm3*(Tfark-Tsur)*(dt-Dt) - x(5) )/dt; % Asl�nda kalan (dt-Dt) s�resi sonunda ula�aca�� h�za ba�tan(wr h�z�ndan) itibaren dt s�resi sonuna kadar t�rev buymu� gibi ula�s�n diye
    end
end
%*******************

xd=[btu*(vdn-(Rs+M2_Lr*a33)*x(1)+M_Lr*(a33*x(3)+x(5)*x(4)))+wg*x(2);
    btu*(vqn-(Rs+M2_Lr*a33)*x(2)+M_Lr*(a33*x(4)-x(5)*x(3)))-wg*x(1);
    a33*(M*x(1)-x(3))+(wg-x(5))*x(4);
    a33*(M*x(2)-x(4))-(wg-x(5))*x(3);
    wrd];
