global wg vdn vqn TL i bir_dt dt;
global btu Rs M2_Lr M_Lr M a33 gm1 gm2 gm3 Bf gm1Ji TCoulomb;
global r wrf trq_ref

% MOTOR PARAMETERS
Rs=0.2147; M=0.06419; Ls=0.000991+M; Lr=Ls; Rr=0.2205; np=4; Ji=0.102; Bf=0.009541; TCoulomb=1e-2;
% Rs=0.08233; Rr=0.0503;M=0.02711; Ls=M+0.000724; Lr=M+0.000724; np=2;
% Bf=0.02791; Ji=0.37*4; TCoulomb=1e-2;
% Rs=1.28333; Rr=0.9233; Ls=0.1418333; Lr=0.1430333; M=0.1373333; np=2;
% Bf=0.0028; Ji=0.1;
%Rs=1; Rr=3.898; Ls=0.2410; Lr=0.2167; M=Lr; np=2;
%Ji=0.0834; Bf=0.00178;
Udc=300; % DC hat voltaj�

% CALCULATED CONSTANTS
btu=Lr/(Lr*Ls-M^2); M2_Lr=M^2/Lr; M_Lr=M/Lr; a33=Rr/Lr;
gm1=3*np*M/2/Ji/Lr; gm2=Bf/Ji; gm3=1/Ji;
gm1_M_Ji=gm1*M*Ji; gm1Ji=gm1*Ji;
anahtar_katsayi_matrisi=[1/3 -1/6 -1/6;0 sqrt(3)/6 -sqrt(3)/6];

% SIMULATION PARAMETERS
dt=0.0001; tf=20; dT=10*dt; bir_dt=1/dt; 
N=10000;		% Plot figure at every N points simulation

% CONTROL PARAMETERS
Kp_hiz=5; Ki_hiz_dt=200*dt; trq_max=200; trq_min=-200;	% Speed control parameters
err_torque_hys=0.1; err_flux_hys=0.002; % Histerezis band� geni�likleri
Flux_ref=0.5; % Stator flux referans�;
modu=1;

nd=0.05*0; nq=0.05*0; nw=1*0; nvd=2*0; nvq=2*0;	% noise (randn) coefficients for id, iq, wr measurements and vd,vq inputs

% INITIAL CONDITIONS
tf=tf-1e-10;	% In order to secure the termination at the right time
lngth=ceil(tf/dt)+1;	% Determine the size before to ensure fast simulation
t=zeros(lngth,1); wr=t; id=t; iq=t;
pd=t; pq=t; vd=t; vq=t; ws=t;			% pd, pq: rotor flux components
th=t; TL=t; wg=0;				% wg is reference frame speed (assign below)
trq_int=0; im_int=0; it_int=0;			% FOC integral initiations
i=1; j=0;
xa=[id(i);iq(i);pd(i);pq(i);wr(i)];		% present state
wer_int=0; wrmd=0; trq_ref=0;
psd=t; psq=t; % Stator flux tahminleri
flux_d=1; % Artarak ba�la
torque_d1=0; torque_d2=0;
Te=t; % Elektromekanik tork tahmini
vdn=vd(i)+nvd*randn(1); vqn=vq(i)+nvq*randn(1);				% Noisy inputs

% STARTING
figure(1),pause(1),	% figure will be updated automatically
while t(i)<tf,
	ip=i+1; t(ip)=t(i)+dt;		% ip is next time step index
	TL(ip)=0;%10*sign(sin(10*t(ip)));
%	if t(ip)>=5, TL(ip)=-30; modu=-1; end,	% Various load torque selections
%	if t(ip)>=10, TL(ip)=0; end,

	% ACTUAL SYSTEM
	k1=im_de(t(i),xa)*dt;
    k2=im_de(t(i)+dt/2,xa+k1/2)*dt;		% 4-step RKM solution
	k3=im_de(t(i)+dt/2,xa+k2/2)*dt;
    k4=im_de(t(i)+dt,xa+k3)*dt;	% with fixed time steps
	xa=xa+(k1+k2*2+k3*2+k4)/6;
	th(ip)=th(i)+(ws(i)-wg)*dt;	% Angle of rotor flux with respect to the reference frame d-axis
	if th(ip)>2*pi, th(ip)=th(ip)-2*pi; end,			% Limiting the angle
	if th(ip)<-2*pi, th(ip)=th(ip)+2*pi; end,
	id(ip)=xa(1); iq(ip)=xa(2);					% next values
	pd(ip)=xa(3); pq(ip)=xa(4);
	wr(ip)=xa(5);

	% MEASUREMENTS   
	yd=id(i)+nd*randn(1); yq=iq(i)+nq*randn(1); yw=wr(i)+nw*randn(1);	% Noisy measurements (yw is not used in sensorless operation)

	% Vector rotation
	sn_th=sin(th(i)); cs_th=cos(th(i));
	im_fb=yd*cs_th+yq*sn_th;		% magnetising current feedback
	it_fb=-yd*sn_th+yq*cs_th;		% torque current feedback
	TLe=TL(i);		% TLe will be used in observer (it may be changed below)

	% REFERENCE MODEL
	% Magnetising current reference
	i_mag_rf=7;
	%ims=0.03*(sin(18*pi*t(ip)))*i_mag_rf; i_mag_rf=i_mag_rf+ims;	% activate and modify for injection signal (used for parameter estimations)
	Kt=gm1_M_Ji*i_mag_rf;			% torque constant
	it_max=trq_max/Kt; it_min=trq_min/Kt;	% torque current limits

	% Speed reference
%	wrf=300+40*sin(t(ip)*pi*4);
	wrf=300*(sign(sin(t(ip)*pi/5)));	% reversal
%	if t(ip)>=15, wrf=-300; end,
%	if (t(ip)<1.999999) & (t(ip)>0.999999) wrf(ip)=-300; end;

    % TAHM�NLER
    % Stator flux tahmini
    psd(ip)=psd(i)+(vd(i)-Rs*yd)*dt;
    psq(ip)=psq(i)+(vq(i)-Rs*yq)*dt;
    % Sekt�r bul
    sektor=floor( (atan2(psq(i),psd(i))+pi/6 )*3/pi)+1;
    if sektor < 1, sektor=sektor+6; end,
    if sektor > 6, sektor=sektor-6; end, % 1<=sektor<=6 yapt�k
    akimsektor=floor( (atan2(iq(i),id(i))+pi/6 )*3/pi)+1;
    if akimsektor < 1, akimsektor=akimsektor+6; end,
    if akimsektor > 6, akimsektor=akimsektor-6; end, % 1<=akimsektor<=6 yapt�k

    % Elektromekanik tork tahmini
    Te(i)=1.5*np*(psd(i)*yq-psq(i)*yd);
        
    % CONTROL
    
    % H�z kontrol�
    wer=wrf-yw;
    wer_int=wer_int+Ki_hiz_dt*wer; oransal=Kp_hiz*wer;
    trq_ref=oransal+wer_int;
    if trq_ref > trq_max, trq_ref=trq_max; end
    if trq_ref < trq_min, trq_ref=trq_min; end
    wer_int=trq_ref-oransal; % integrali g�ncelledik, limite tak�lma ihtimalinden dolay�
      
    % Tork histerezis kontrol�
    trq_er=trq_ref-Te(i);
%     torque_d=0;
%     if trq_er > err_torque_hys, torque_d=1; end
%     if trq_er < -err_torque_hys, torque_d=-1; end
    if trq_er > err_torque_hys, torque_d1=1; end
    if trq_er < 0, torque_d1=0; end
    if trq_er > 0, torque_d2=0; end
    if trq_er < -err_torque_hys, torque_d2=-1; end
    torque_d=torque_d1+torque_d2;

    % Flux histerezis kontrol�
    Flux_er=Flux_ref-sqrt(psd(i)^2+psq(i)^2);
    if Flux_er > err_flux_hys, flux_d=1; end
    if Flux_er < -err_flux_hys, flux_d=-1; end
 
    % PWM anahtar konumlar�  1:+'ya ba�lar   -1:-'ye ba�lar
    switch sektor,
      case 1,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[1;1;-1] + (flux_d==-1)*[-1;1;-1]; % v2 ya da v3
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[1;1;1] + (flux_d==-1)*[-1;-1;-1]; % v7 ya da v0
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[1;-1;1] + (flux_d==-1)*[-1;-1;1]; % v6 ya da v5
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      case 2,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[-1;1;-1] + (flux_d==-1)*[-1;1;1]; % v3 ya da v4
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[-1;-1;-1] + (flux_d==-1)*[1;1;1]; % v0 ya da v7
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[1;-1;-1] + (flux_d==-1)*[1;-1;1]; % v1 ya da v6
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      case 3,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[-1;1;1] + (flux_d==-1)*[-1;-1;1]; % v4 ya da v5
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[1;1;1] + (flux_d==-1)*[-1;-1;-1]; % v7 ya da v0
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[1;1;-1] + (flux_d==-1)*[1;-1;-1]; % v2 ya da v1
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      case 4,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[-1;-1;1] + (flux_d==-1)*[1;-1;1]; % v5 ya da v6
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[-1;-1;-1] + (flux_d==-1)*[1;1;1]; % v0 ya da v7
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[-1;1;-1] + (flux_d==-1)*[1;1;-1]; % v3 ya da v2
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      case 5,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[1;-1;1] + (flux_d==-1)*[1;-1;-1]; % v6 ya da v1
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[1;1;1] + (flux_d==-1)*[-1;-1;-1]; % v7 ya da v0
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[-1;1;1] + (flux_d==-1)*[-1;1;-1]; % v4 ya da v3
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      case 6,
        switch torque_d,
            case 1, % tork artmal�
                sABC = (flux_d==1)*[1;-1;-1] + (flux_d==-1)*[1;1;-1]; % v1 ya da v2
            case 0, % tork sabit kalmal�
                sABC = (flux_d==1)*[-1;-1;-1] + (flux_d==-1)*[1;1;1]; % v0 ya da v7
            case -1, % tork azalmal�
                sABC = (flux_d==1)*[-1;-1;1] + (flux_d==-1)*[-1;1;1]; % v5 ya da v4
            otherwise
                error(['Hatal� giri� = ',num2str(torque_d)]);
        end      
      otherwise
        error(['Hatal� giri� = ',num2str(torque_d)]);
    end      
if t(i)>2, sABC', end
    % Anahtar konumlar� i�in vd vq ne olur?
    vdq = anahtar_katsayi_matrisi*sABC*Udc;
    vd(ip)=vdq(1); vq(ip)=vdq(2);
	vdn=vd(ip)+nvd*randn(1); vqn=vq(ip)+nvq*randn(1);				% Noisy inputs

%    vd(ip)=200*cos(314*t(ip));    vq(ip)=200*sin(314*t(ip)); % fixed input

%   Ara g�zlem    
%      if t(i)>3 & t(i)<3.01,
%        trq_ref=trq_ref,
%      end
	wg=0;	% ws for synch. ref. frame, 0 for stationary ref. frame


	% WHEN SHORTER LOOP ENDS
	if (floor(i/N)*N==i) & i~=1,
		dim=1:ip;
		figure(1), plot(t(dim),[wr(dim)]);axis([0 tf -350 350])
%		figure(2), plot(t(dim),[iq(dim).*cos(th(dim))-id(dim).*sin(th(dim)),itm(dim)]),
%		plot(t(dim),(vd(dim).*id(dim)+vq(dim).*iq(dim)-(Ls-1/btu)*ws(dim).*iq(dim).*id(dim))./(id(dim).*id(dim)+iq(dim).*iq(dim)))
		figure(1),pause(1),
%		time=t(ip)

	end,
	i=ip;
end
figure(1),plot(t,wr)