function [ xd ] = asenkron_turevi( t,x )
%ASENKRON_TUREV� Summary of this function goes here
%   Detailed explanation goes here
global a11 a13 a14 a51 a55 a5T Rs wg vsan TL i
% isd=x(1); isq=x(2); psd=x(3); psq=x(4); wr=x(5);
xd=[-a11        (wg-x(5))       a13   a14*x(5);
    -(wg-x(5))    -a11     -a14*x(5)     a13  ;
    -Rs             0            0        wg  ;
    0              -Rs          -wg        0  ]*x(1:4)+[a14 0;
                                                        0  a14;
                                                        1   0;
                                                        0   1]*vsan;
xd=[xd;
    a51*(x(3)*x(2)-x(4)*x(1))-a55*x(5)-a5T*TL(i)];

end
