global vsan TL i np;
global Ld Lq Rs J B PSI;
% Sim�lasyon parametreleri
t0=0; ts=15; dt=0.001; % ilk ve son zamanlar ile zaman ad�m�
x0=[0;0;0]; % [isd;isq;wr] vekt�r�n�n ba�lang�� �artlar�

% Motor parametreleri
Rs=3.658; Ld=0.1496; Lq=Ld; np=2;
B=0.00405; J=0.004; PSI=0.7;

% Denetim parametreleri
Kp_hiz=3; Ki_hiz_dt=30*dt; tork_max=50; tork_min=-50;
Kp_isq=2; Ki_isq_dt=20*dt; vsq_max=400; vsq_min=-400;
Kp_isd=35; Ki_isd_dt=10*dt; vsd_max=400; vsd_min=-400;
isd_talebi=0; % Rotor ak�s�na destek talebiyle orant�l�

% Hesaplanm�� marametreler
Kt=1.5*np*PSI;

% Ba�lang�� de�erleri
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,nt); % �imdilik s�f�r olsun (sat�r)
vsd=t; vsq=t; TL=t; % �imdilik s�f�r olsunlar (sat�r)
vsn=[vsd;vsq];
x=[t;t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [isd;isq;wr] vekt�r�)
isd=x(1,:); isq=x(2,:); wr=x(3,:);
wrf=t;
t(1)=t0;
x(:,1)=x0;
wr_integral=0; isq_integral=0; isd_integral=0;

% D�ng� ba�l�yor
for i=1:nt-1
    % Runga Kutta
    vsan=vsn(:,i);
    k1=pmsm_turevi(t(i),x(:,i))*dt;
    k2=pmsm_turevi(t(i)+dt/2,x(:,i)+k1/2)*dt;
    k3=pmsm_turevi(t(i)+dt/2,x(:,i)+k2/2)*dt;
    k4=pmsm_turevi(t(i)+dt,x(:,i)+k3)*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
    t(i+1)=t(i)+dt;
    
    % �l��mler
    isd(i+1)=x(1,i+1); isq(i+1)=x(2,i+1);
    wr(i+1)=x(3,i+1);

    
    % H�z denetimi
    wrf(i)=300; % �imdilik sabit h�z talep ediliyor.
    wr_hata=wrf(i)-wr(i);
    wr_oransal=Kp_hiz*wr_hata;
    wr_integral=wr_integral+Ki_hiz_dt*wr_hata;
    Te_talebi=wr_oransal+wr_integral;
    if Te_talebi > tork_max, Te_talebi=tork_max; end
    if Te_talebi < tork_min, Te_talebi=tork_min; end
    wr_integral=Te_talebi-wr_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Tork ak�m� denetimi
    isq_talebi=Te_talebi/Kt;
    isq_hata=isq_talebi-isq(i);
    isq_oransal=Kp_isq*isq_hata;
    isq_integral=isq_integral+Ki_isq_dt*isq_hata;
    vsq(i+1)=isq_oransal+isq_integral;
    if vsq(i+1) > vsq_max, vsq(i+1)=vsq_max; end
    if vsq(i+1) < vsq_min, vsq(i+1)=vsq_min; end
    isq_integral=vsq(i+1)-isq_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % M�knat�slanma ak�m� denetimi
    isd_hata=isd_talebi-isd(i);
    isd_oransal=Kp_isd*isd_hata;
    isd_integral=isd_integral+Ki_isd_dt*isd_hata;
    vsd(i+1)=isd_oransal+isd_integral;
    if vsd(i+1) > vsd_max, vsd(i+1)=vsd_max; end
    if vsd(i+1) < vsd_min, vsd(i+1)=vsd_min; end
    isd_integral=vsd(i+1)-isd_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� ak�m talebini
                                      % vermesi i�in yeniden ayarland�
    
    %vsd(i+1)=220; vsq(i+1)=220; wg=100*pi; % �imdilik sabit (denetim yok)
    vsn(:,i+1)=[vsd(i+1);vsq(i+1)];
    if t(i+1)>2, TL(i+1)=6; end
end
figure(1),set(1,'Name','dq ak�mlar�')
plot(t,x(1:2,:))
figure(2),plot(t,x(3,:)),set(2,'Name','Elektriksel a��sal h�z')
text(0.15,300,'\omega_r','HorizontalAlignment','left')
xlabel('t (saniye)'); ylabel('h�z (rad/s)')