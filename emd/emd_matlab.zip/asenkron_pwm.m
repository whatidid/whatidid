global a11 a13 a14 a51 a55 a5T Rs wg vsan TL i ii
% Sim�lasyon parametreleri
t0=0; ts=6; dt=0.001; % ilk ve son zamanlar ile zaman ad�m�
x0=[0;0;0;0;0]; % [isd;isq;psd;psq;wr] vekt�r�n�n ba�lang�� �artlar�

% Motor parametreleri
Rs=1.28333; Rr=0.9233; Ls=0.1418333; Lr=0.1430333; M=0.1373333; np=2;
B=0.0028; J=0.1;
Vdc=600; % DC hat voltaj�

% Denetim parametreleri
Kp_hiz=12; Ki_hiz_dt=300*dt; tork_max=50; tork_min=-50;
Kp_isq=1; Ki_isq_dt=500*dt; vsq_max=400; vsq_min=-400;
Kp_isd=5; Ki_isd_dt=100*dt; vsd_max=400; vsd_min=-400;
isd_talebi=8.5; % Rotor ak�s� talebi / M

% Hesaplanm�� parametreler
a11=(Rr*Ls+Rs*Lr)/(Lr*Ls-M^2); a13=Rr/(Lr*Ls-M^2); a14=Lr/(Lr*Ls-M^2);
a51=3*np^2/2/J; a55=B/J; a5T=np/J; kayma_katsayisi=Rr/Lr/isd_talebi;
Kt=1.5*np*M^2/Lr*isd_talebi;
dt_Vdc=dt/Vdc; Vdc_2=Vdc/2;

% Sabitler
V0=[0;0;0]; V1=[1;0;0]; V3=[0;1;0]; V5=[0;0;1];
V7=1-V0; V4=1-V1; V6=1-V3; V2=1-V5; % de�illeri al�nd�
vektors=[V0,V1,V2,V3,V4,V5,V6,V7];
kok3=sqrt(3);

% Ba�lang�� de�erleri
% t, x, vsn ve sABC boyutlar� di�erlerinin 4 kat� uzunlukta. Di�erlerinin her bir
% ad�m�na kar��l�k bunlar 4 alt ad�m halinde ele al�nd��� i�in.
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,4*nt-3); % �imdilik s�f�r olsun (sat�r)
vsd=zeros(1,nt); vsq=vsd; TL=vsd; % �imdilik s�f�r olsunlar (sat�r)
vs_al=vsd; vs_bt=vsd; % �imdilik s�f�r olsun
vsn=[t;t;t]; x=[t;t;t;t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [isd;isq;psd;psq;wr] vekt�r�)
sABC=[t;t;t]; % Anahtarlama vekt�rleri
is_al=vsd; is_bt=vsd; wr=vsd;
isd=vsd; isq=vsd; theta=vsd;
cs=cos(theta(1)); sn=sin(theta(1));
wrf=vsd; wg=0; ws=vsd;
t(1)=t0; x(:,1)=x0;
is_al(1)=x0(1); is_bt(1)=x0(2); wr(1)=x0(5);
wr_integral=0; isq_integral=0; isd_integral=0;
tek=1; dt1=dt/4; dt2=dt1; dt3=dt1; dt4=dt1; % ilk ad�m �nemsiz

% D�ng� ba�l�yor
for i=1:nt-1
    i4=4*i-3; % 4 alt ad�ma b�l�nm��lerin (t, x ve vsn) i. ad�m�n ba��na kar��l�k gelen indisi
    % Asl�nda dt ad�m� i�in Runga-Kutta bir defa de�il 4 par�a halinde
    % �al��t�r�lacak
    
    % Runga Kutta dt1 i�in
    ii=i4; vsan=vsn(1:2,ii);
    k1=asenkron_turevi(t(ii),x(:,ii))*dt1;
    k2=asenkron_turevi(t(ii)+dt1/2,x(:,ii)+k1/2)*dt1;
    k3=asenkron_turevi(t(ii)+dt1/2,x(:,ii)+k2/2)*dt1;
    k4=asenkron_turevi(t(ii)+dt1,x(:,ii)+k3)*dt1;
    x(:,i4+1)=x(:,ii)+(k1+2*k2+2*k3+k4)/6;
    t(i4+1)=t(ii)+dt1;
    % Runga Kutta dt2 i�in
    ii=i4+1; vsan=vsn(1:2,ii);
    k1=asenkron_turevi(t(ii),x(:,ii))*dt2;
    k2=asenkron_turevi(t(ii)+dt2/2,x(:,ii)+k1/2)*dt2;
    k3=asenkron_turevi(t(ii)+dt2/2,x(:,ii)+k2/2)*dt2;
    k4=asenkron_turevi(t(ii)+dt2,x(:,ii)+k3)*dt2;
    x(:,i4+2)=x(:,ii)+(k1+2*k2+2*k3+k4)/6;
    t(i4+2)=t(ii)+dt2;
    % Runga Kutta dt3 i�in
    ii=i4+2; vsan=vsn(1:2,ii);
    k1=asenkron_turevi(t(ii),x(:,ii))*dt3;
    k2=asenkron_turevi(t(ii)+dt3/2,x(:,ii)+k1/2)*dt3;
    k3=asenkron_turevi(t(ii)+dt3/2,x(:,ii)+k2/2)*dt3;
    k4=asenkron_turevi(t(ii)+dt3,x(:,ii)+k3)*dt3;
    x(:,i4+3)=x(:,ii)+(k1+2*k2+2*k3+k4)/6;
    t(i4+3)=t(ii)+dt3;
    % Runga Kutta dt4 i�in
    ii=i4+3; vsan=vsn(1:2,ii);
    k1=asenkron_turevi(t(ii),x(:,ii))*dt4;
    k2=asenkron_turevi(t(ii)+dt4/2,x(:,ii)+k1/2)*dt4;
    k3=asenkron_turevi(t(ii)+dt4/2,x(:,ii)+k2/2)*dt4;
    k4=asenkron_turevi(t(ii)+dt4,x(:,ii)+k3)*dt4;
    x(:,i4+4)=x(:,ii)+(k1+2*k2+2*k3+k4)/6;
    t(i4+4)=t(ii)+dt4;
    
    % �l��mler (4 ad�m�n sonunda al�n�yor)
    is_al(i+1)=mean(x(1,i4+(1:4)));
    is_bt(i+1)=mean(x(2,i4+(1:4)));
    wr(i+1)=wr(i)*0.+1*mean(x(5,i4+(1:4)));
    % alfa,beta --> dq
    isd(i+1)=(cs*is_al(i+1)+sn*is_bt(i+1));
    isq(i+1)=(-sn*is_al(i+1)+cs*is_bt(i+1));
    
    % H�z denetimi
    wrf(i)=300; % �imdilik sabit h�z talep ediliyor.
    wr_hata=wrf(i)-wr(i);
    wr_oransal=Kp_hiz*wr_hata;
    wr_integral=wr_integral+Ki_hiz_dt*wr_hata;
    Te_talebi=wr_oransal+wr_integral;
    if Te_talebi > tork_max, Te_talebi=tork_max; end
    if Te_talebi < tork_min, Te_talebi=tork_min; end
    wr_integral=Te_talebi-wr_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Tork ak�m� denetimi
    isq_talebi=Te_talebi/Kt;
    isq_hata=isq_talebi-isq(i);
    isq_oransal=Kp_isq*isq_hata;
    isq_integral=isq_integral+Ki_isq_dt*isq_hata;
    vsq(i+1)=isq_oransal+isq_integral;
    if vsq(i+1) > vsq_max, vsq(i+1)=vsq_max; end
    if vsq(i+1) < vsq_min, vsq(i+1)=vsq_min; end
    isq_integral=vsq(i+1)-isq_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % M�knat�slanma ak�m� denetimi
    isd_hata=isd_talebi-isd(i);
    isd_oransal=Kp_isd*isd_hata;
    isd_integral=isd_integral+Ki_isd_dt*isd_hata;
    vsd(i+1)=isd_oransal+isd_integral;
    if vsd(i+1) > vsd_max, vsd(i+1)=vsd_max; end
    if vsd(i+1) < vsd_min, vsd(i+1)=vsd_min; end
    isd_integral=vsd(i+1)-isd_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� ak�m talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Kayma komutu
    ws(i+1)=wr(i)+kayma_katsayisi*isq(i);
    theta(i+1)=theta(i)+ws(i+1)*dt;
    cs=cos(theta(i+1)); sn=sin(theta(i+1));
    wg=0; % Durgun eksenlerde �al���l�yor.
    
    %vsd(i+1)=-400; vsq(i+1)=300; wg=100*pi; % �imdilik sabit (denetim yok)
    
    % dq --> alfa,beta
    vs_al(i+1)=cs*vsd(i+1)-sn*vsq(i+1);
    vs_bt(i+1)=sn*vsd(i+1)+cs*vsq(i+1);
    % Bu bizim referans vekt�r�m�z, bunu kutupsal Vref /__ gamma cinsinden
    % yazal�m ve sekt�r�n� bulal�m.
    [gamma,Vref]=cart2pol(vs_al(i+1),vs_bt(i+1));
    sektor=floor(gamma*3/pi)+1;
    if sektor<1, sektor=sektor+6;
    elseif sektor>6, sektor=sektor-6;
    end
    % sektor+2 s�tunu (Vsektor+1), vektors'un 8. s�tunu olmamal�
    % olursa 2. s�tun (V1) al�nmal�
    sektora2=sektor+2; if sektora2==8, sektora2=2; end
    
    % Vref'i ger�ekle�tirecek anahtarlama komutlar� belirlenecek
    % her dt ad�m� 4 par�aya b�l�necek, her par�ada 3 bitlik (abc)
    % anahtarlama komutunun yaln�z bir biti de�i�ecek.
    if tek==1, % V0 ile ba�layan yar� ad�mdaysak
        sABC(:,i4+4)=V0; sABC(:,i4+7)=V7; 
        if 2*floor(sektor/2)==sektor, % �ift numaral� sekt�rdeysek
            sABC(:,i4+5)=vektors(:,sektora2); % asl�nda bu Vsektor+1 demek
            dt2=kok3*dt_Vdc*Vref*sin(gamma-(sektor-1)*pi/3); % T_k+1 form�l�
            sABC(:,i4+6)=vektors(:,sektor+1); % asl�nda bu Vsektor demek
            dt3=kok3*dt_Vdc*Vref*sin(sektor*pi/3-gamma); % T_k form�l�
        else % Tek numaral� sekt�rdeysek
            sABC(:,i4+5)=vektors(:,sektor+1); % asl�nda bu Vsektor demek
            dt2=kok3*dt_Vdc*Vref*sin(sektor*pi/3-gamma); % T_k form�l�
            sABC(:,i4+6)=vektors(:,sektora2); % asl�nda bu Vsektor+1 demek
            dt3=kok3*dt_Vdc*Vref*sin(gamma-(sektor-1)*pi/3); % T_k+1 form�l�
        end
    else % V7 ile ba�layan yar� ad�mdaysak �ncekinin tersi s�ra uygulan�r.
        sABC(:,i4+4)=V7; sABC(:,i4+7)=V0;
        if 2*floor(sektor/2)==sektor, % �ift numaral� sekt�rdeysek
            sABC(:,i4+5)=vektors(:,sektor+1); % asl�nda bu Vsektor demek
            dt2=kok3*dt_Vdc*Vref*sin(sektor*pi/3-gamma); % T_k form�l�
            sABC(:,i4+6)=vektors(:,sektora2); % asl�nda bu Vsektor+1 demek
            dt3=kok3*dt_Vdc*Vref*sin(gamma-(sektor-1)*pi/3); % T_k+1 form�l�
        else % Tek numaral� sekt�rdeysek
            sABC(:,i4+5)=vektors(:,sektora2); % asl�nda bu Vsektor+1 demek
            dt2=kok3*dt_Vdc*Vref*sin(gamma-(sektor-1)*pi/3); % T_k+1 form�l�
            sABC(:,i4+6)=vektors(:,sektor+1); % asl�nda bu Vsektor demek
            dt3=kok3*dt_Vdc*Vref*sin(sektor*pi/3-gamma); % T_k form�l�
        end
    end
    if dt2+dt3>dt, azalt=dt/(dt2+dt3); dt2=azalt*dt2; dt3=azalt*dt3; end
    dt1=(dt-dt2-dt3)*0.5; dt4=dt1;

    % Sonra her dt ad�m�n�n her 4'de 1 par�as�nda motor �zerine d��en
    % ger�ek voltaj de�erleri hesaplanacak
    vsn(:,i4+4)=abc2dqo(sABC(:,i4+4)*Vdc-Vdc_2); % sABC*Vdc, kayna��n eksi ucuna g�re abc fazlar�n�n voltaj�
    vsn(:,i4+5)=abc2dqo(sABC(:,i4+5)*Vdc-Vdc_2); % ama biz, kayna��n orta potansiyeline (kullan�lmayan n�tre) g�re abc
    vsn(:,i4+6)=abc2dqo(sABC(:,i4+6)*Vdc-Vdc_2); % fazlar�n�n voltaj�n� al�yoruz; bu y�zden Vdc/2'yi ��kar�yoruz.
    vsn(:,i4+7)=abc2dqo(sABC(:,i4+7)*Vdc-Vdc_2); % Sonra da bunu alfa, beta eksenlerine d�n��t�r�yoruz.

    if t(i4+4)>2, TL(i+1)=15; end
    if t(i4+4)>4, TL(i+1)=0; end
    tek=1-tek; % Bir dt ad�m�nda V0 ile ba�lay�p V7 ile bitirece�iz, bir sonrakinde ise V7 ile ba�lay�p
               % V0 ile bitirece�iz. Bir �yle bir b�yle devam edecek.
end
figure(1),set(1,'Name','alfa,beta ak�mlar� ve ak�lar�'),zoom on
subplot(2,1,1),plot(t,x(1:2,:))
subplot(2,1,2),plot(t,x(3:4,:))
figure(2),plot(t,x(5,:)),set(2,'Name','Elektriksel a��sal h�z'),zoom on
text(0.25,320,'\omega_r','HorizontalAlignment','left')
xlabel('t (saniye)'); ylabel('h�z (rad/s)')