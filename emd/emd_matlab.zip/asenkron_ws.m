global a11 a13 a14 a51 a55 a5T Rs wg vsan TL i
% Sim�lasyon parametreleri
t0=0; ts=5; dt=0.001; % ilk ve son zamanlar ile zaman ad�m�
x0=[0;0;0;0;0]; % [isd;isq;psd;psq;wr] vekt�r�n�n ba�lang�� �artlar�

% Motor parametreleri
Rs=1.28333; Rr=0.9233; Ls=0.1418333; Lr=0.1430333; M=0.1373333; np=2;
B=0.0028; J=0.1;

% Denetim parametreleri
Kp_hiz=12; Ki_hiz_dt=300*dt; tork_max=50; tork_min=-50;
Kp_isq=1; Ki_isq_dt=500*dt; vsq_max=400; vsq_min=-400;
Kp_isd=5; Ki_isd_dt=100*dt; vsd_max=400; vsd_min=-400;
isd_talebi=8.5; % Rotor ak�s� talebi / M

% Hesaplanm�� marametreler
a11=(Rr*Ls+Rs*Lr)/(Lr*Ls-M^2); a13=Rr/(Lr*Ls-M^2); a14=Lr/(Lr*Ls-M^2);
a51=3*np^2/2/J; a55=B/J; a5T=np/J; kayma_katsayisi=Rr/Lr/isd_talebi;
Kt=1.5*np*M^2/Lr*isd_talebi;

% Ba�lang�� de�erleri
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,nt); % �imdilik s�f�r olsun (sat�r)
vsd=t; vsq=t; TL=t; % �imdilik s�f�r olsunlar (sat�r)
vsn=[vsd;vsq];
x=[t;t;t;t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [isd;isq;psd;psq;wr] vekt�r�)
isd=x(1,:); isq=x(2,:); wr=x(5,:);
wrf=t; wg=0;
t(1)=t0;
x(:,1)=x0;
wr_integral=0; isq_integral=0; isd_integral=0;

% D�ng� ba�l�yor
for i=1:nt-1
    % Runga Kutta
    vsan=vsn(:,i);
    k1=asenkron_turevi(t(i),x(:,i))*dt;
    k2=asenkron_turevi(t(i)+dt/2,x(:,i)+k1/2)*dt;
    k3=asenkron_turevi(t(i)+dt/2,x(:,i)+k2/2)*dt;
    k4=asenkron_turevi(t(i)+dt,x(:,i)+k3)*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
    t(i+1)=t(i)+dt;
    
    % �l��mler
    isd(i+1)=x(1,i+1); isq(i+1)=x(2,i+1);
    wr(i+1)=x(5,i+1);

    
    % H�z denetimi
    wrf(i)=300; % �imdilik sabit h�z talep ediliyor.
    wr_hata=wrf(i)-wr(i);
    wr_oransal=Kp_hiz*wr_hata;
    wr_integral=wr_integral+Ki_hiz_dt*wr_hata;
    Te_talebi=wr_oransal+wr_integral;
    if Te_talebi > tork_max, Te_talebi=tork_max; end
    if Te_talebi < tork_min, Te_talebi=tork_min; end
    wr_integral=Te_talebi-wr_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Tork ak�m� denetimi
    isq_talebi=Te_talebi/Kt;
    isq_hata=isq_talebi-isq(i);
    isq_oransal=Kp_isq*isq_hata;
    isq_integral=isq_integral+Ki_isq_dt*isq_hata;
    vsq(i+1)=isq_oransal+isq_integral;
    if vsq(i+1) > vsq_max, vsq(i+1)=vsq_max; end
    if vsq(i+1) < vsq_min, vsq(i+1)=vsq_min; end
    isq_integral=vsq(i+1)-isq_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % M�knat�slanma ak�m� denetimi
    isd_hata=isd_talebi-isd(i);
    isd_oransal=Kp_isd*isd_hata;
    isd_integral=isd_integral+Ki_isd_dt*isd_hata;
    vsd(i+1)=isd_oransal+isd_integral;
    if vsd(i+1) > vsd_max, vsd(i+1)=vsd_max; end
    if vsd(i+1) < vsd_min, vsd(i+1)=vsd_min; end
    isd_integral=vsd(i+1)-isd_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� ak�m talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Kayma komutu
    wg=wr(i)+kayma_katsayisi*isq(i);
    
    
    %vsd(i+1)=-400; vsq(i+1)=300; wg=100*pi; % �imdilik sabit (denetim yok)
    vsn(:,i+1)=[vsd(i+1);vsq(i+1)];
    if t(i+1)>1, TL(i+1)=30; end
end
figure(1),set(1,'Name','dq ak�mlar� ve ak�lar�')
subplot(2,1,1),plot(t,x(1:2,:))
subplot(2,1,2),plot(t,x(3:4,:))
figure(2),plot(t,x(5,:)),set(2,'Name','Elektriksel a��sal h�z')
text(0.15,300,'\omega_r','HorizontalAlignment','left')
xlabel('t (saniye)'); ylabel('h�z (rad/s)')