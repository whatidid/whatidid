% sarg�l� rotorlu senkron motor modeli
% senkron reference frame
global vsan TL i s11 s12 s13 s22 s23 s31 s32 s33 b11 b13 b22 b31 b33 c1 c2 c3;
% Sim�lasyon parametreleri
t0=0; ts=10; dt=0.0002; % ilk ve son zamanlar ile zaman ad�m�
x0=[0;0;0;0]; % [isd;isq;if;wr] vekt�r�n�n ba�lang�� �artlar�

% Motor parametreleri
Rs=3.658; Ls=0.1496; Rf=30; Lf=0.83; M=0.35; np=2;
B=0.00405; J=0.004;

% Denetim parametreleri
Kp_hiz=5; Ki_hiz_dt=25*dt; tork_max=50; tork_min=-50;
Kp_isq=1; Ki_isq_dt=5*dt; vsq_max=400; vsq_min=-400;
Kp_isd=5; Ki_isd_dt=7*dt; vsd_max=400; vsd_min=-400;
Kp_ifu=30; Ki_ifu_dt=100*dt; vf_max=100; vf_min=-100;
isd_talebi=0; % Rotor ak�s�na destek talebiyle orant�l�
ifu_talebi=2;  % ifu uyart�m ak�m� (iF dedikleri)

% Hesaplanm�� marametreler
Kt=1.5*np*M;
s11=Rs*Lf/(Ls*Lf-M^2);   s12=Ls*Lf/(Ls*Lf-M^2);  s13=Rf*M/(Ls*Lf-M^2);
s22=Rs/Ls;          s23=M/Ls;
s31=Rs*M/(Ls*Lf-M^2);    s32=Ls*M/(Ls*Lf-M^2);   s33=Rf*Ls/(Ls*Lf-M^2);
b11=Lf/(Ls*Lf-M^2);   b13=M/(Ls*Lf-M^2);
b22=1/Ls;
b31=M/(Ls*Lf-M^2);    b33=Ls/(Ls*Lf-M^2);
c1=3*np^2*M/(2*J);    c2=B/J;    c3=np/J;

% Ba�lang�� de�erleri
nt=floor(ts/dt)+1; % sim�lasyon ad�m say�s�
t=zeros(1,nt); % �imdilik s�f�r olsun (sat�r)
vsd=t; vsq=t; vf=t; TL=t; % �imdilik s�f�r olsunlar (sat�r)
vsn=[vsd;vsq;vf];
x=[t;t;t;t]; % �imdilik s�f�r olsun (i. s�tunu t(i) an�n�n [isd;isq;if;wr] vekt�r�)
isd=x(1,:); isq=x(2,:); ifu=x(3,:); wr=x(4,:);
wrf=t;
t(1)=t0;
x(:,1)=x0;
wr_integral=0; isq_integral=0; isd_integral=0; ifu_integral=0;

% D�ng� ba�l�yor
for i=1:nt-1
    % Runga Kutta
    vsan=vsn(:,i);
    k1=srsm_turevi(t(i),x(:,i))*dt;
    k2=srsm_turevi(t(i)+dt/2,x(:,i)+k1/2)*dt;
    k3=srsm_turevi(t(i)+dt/2,x(:,i)+k2/2)*dt;
    k4=srsm_turevi(t(i)+dt,x(:,i)+k3)*dt;
    x(:,i+1)=x(:,i)+(k1+2*k2+2*k3+k4)/6;
    t(i+1)=t(i)+dt;
    
    % �l��mler
    isd(i+1)=x(1,i+1); isq(i+1)=x(2,i+1); ifu(i+1)=x(3,i+1);
    wr(i+1)=x(4,i+1);

    
    % H�z denetimi
    wrf(i)=300; % �imdilik sabit h�z talep ediliyor.
    wr_hata=wrf(i)-wr(i);
    wr_oransal=Kp_hiz*wr_hata;
    wr_integral=wr_integral+Ki_hiz_dt*wr_hata;
    Te_talebi=wr_oransal+wr_integral;
    if Te_talebi > tork_max, Te_talebi=tork_max; end
    if Te_talebi < tork_min, Te_talebi=tork_min; end
    wr_integral=Te_talebi-wr_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % Tork ak�m� denetimi
    isq_talebi=Te_talebi/Kt;
    isq_hata=isq_talebi-isq(i);
    isq_oransal=Kp_isq*isq_hata;
    isq_integral=isq_integral+Ki_isq_dt*isq_hata;
    vsq(i+1)=isq_oransal+isq_integral;
    if vsq(i+1) > vsq_max, vsq(i+1)=vsq_max; end
    if vsq(i+1) < vsq_min, vsq(i+1)=vsq_min; end
    isq_integral=vsq(i+1)-isq_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� tork talebini
                                      % vermesi i�in yeniden ayarland�
    
    % M�knat�slanma ak�m� denetimi
    isd_hata=isd_talebi-isd(i);
    isd_oransal=Kp_isd*isd_hata;
    isd_integral=isd_integral+Ki_isd_dt*isd_hata;
    vsd(i+1)=isd_oransal+isd_integral;
    if vsd(i+1) > vsd_max, vsd(i+1)=vsd_max; end
    if vsd(i+1) < vsd_min, vsd(i+1)=vsd_min; end
    isd_integral=vsd(i+1)-isd_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� ak�m talebini
                                      % vermesi i�in yeniden ayarland�
                                      
    % Uyart�m ak�m� denetimi
    ifu_hata=ifu_talebi-ifu(i);
    ifu_oransal=Kp_ifu*ifu_hata;
    ifu_integral=ifu_integral+Ki_ifu_dt*ifu_hata;
    vf(i+1)=ifu_oransal+ifu_integral;
    if vf(i+1) > vf_max, vf(i+1)=vf_max; end
    if vf(i+1) < vf_min, vf(i+1)=vf_min; end
    ifu_integral=vf(i+1)-ifu_oransal; % limitlemeye tak�ld�ysa ayn�
                                      % form�lle ayn� ak�m talebini
                                      % vermesi i�in yeniden ayarland�
    
%     vsd(i+1)=220; vsq(i+1)=220; wg=100*pi; % �imdilik sabit (denetim yok)
%     vf(i+1)=60;
    vsn(:,i+1)=[vsd(i+1);vsq(i+1);vf(i+1)];
    if t(i+1)>2, TL(i+1)=1; end
    if t(i+1)>6, TL(i+1)=0; end
end
figure(1),set(1,'Name','dq ve uyart�m ak�mlar�')
plot(t,x(1:3,:))
figure(2),plot(t,x(4,:)),set(2,'Name','Elektriksel a��sal h�z')
text(0.15,300,'\omega_r','HorizontalAlignment','left')
xlabel('t (saniye)'); ylabel('h�z (rad/s)')