function xd=srsm_turevi(t,x)
% sarg�l� rotorlu senkron motor modeli
% senkron reference frame
global vsan TL i s11 s12 s13 s22 s23 s31 s32 s33 b11 b13 b22 b31 b33 c1 c2 c3;
global Ls Rs Rf Lf J B PSI;
% s11=Rs*Lf/(Ls*Lf-M^2);   s12=Ls*Lf/(Ls*Lf-M^2);  s13=Rf*M/(Ls*Lf-M^2);
% s22=Rs/Ls;          s23=M/Ls;
% s31=Rs*M/(Ls*Lf-M^2);    s32=Ls*M/(Ls*Lf-M^2);   s33=Rf*Ls/(Ls*Lf-M^2);
% b11=Lf/(Ls*Lf-M^2);   b13=M/(Ls*Lf-M^2);
% b22=1/Ls;
% b31=M/(Ls*Lf-M^2);    b33=Ls/(Ls*Lf-M^2);
% c1=3*np^2*M/(2*J);    c2=B/J;    c3=np/J;

xd=[-s11   s12*x(4)   s13;
    -x(4)   -s22   -s23*x(4);
     s31  -s32*x(4)  -s33 ]*x(1:3) + [ b11 0 -b13;
                                        0 b22  0;
                                      -b13 0  b33]*vsan;
xd=[xd;
    c1*x(3)*x(2)-c2*x(4)-c3*TL(i)];