function xd=pmsm_turevi(t,x)
% miknatisli senkron motor modeli
% senkron reference frame.
global vsan TL i np;
global Ld Lq Rs J B PSI;
Te=1.5*np*(x(2)*PSI+x(1)*(Ld-Lq));
% if t>2, Te=10.636; end
xd=[(vsan(1)-Rs*x(1)+Lq*x(2)*x(3))/Ld;
    (vsan(2)-Rs*x(2)-x(3)*(Ld*x(1)+PSI))/Lq;
    (Te-TL(i))*np/J-B/J*x(3)];